# RIOTLINE AUDIO QA REPORT

Target master rate: 44100 Hz
WAV files checked: 116
Non-44100 Hz files: 0
Files at digital full scale: 0
Silent/near-silent files: 0
OGG runtime copies: Vorbis q5

Result: PASS

Final in-engine loudness balancing must still be tested on phone speakers and headphones.
