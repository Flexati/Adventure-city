# RIOTLINE — COMPLETE AUDIO PACK

Production audio library for RIOTLINE.

## Coverage
- 6 established music tracks.
- 12 Rookside environmental ambience loops.
- Kai combat, powers and movement accents.
- Zara combat, powers and movement accents.
- Duo switch, synergy and finisher cues.
- Vortex VX-3 engine, drift, summon, hover, damage and repair audio.
- Boss-specific audio identities.
- Common enemy and hazard telegraphs.
- UI, narrative-choice, save, reward and progression sounds.
- Traversal/world foley.

## Formats
Master WAV PCM 16-bit / 44.1 kHz. Runtime OGG Vorbis q5.

## Sonic identity
Kai = precise, short, technological blue-line sound.
Zara = heavier, wider red/orange pressure-wave sound.
Duo = blue + red resolving into magenta/white interference.
Vortex = compact mechanical hatchback character, not supercar fantasy.
Il Regista = broadcast / scanline / editorial-cut language.
Rookside ambience stays quieter and less processed than combat.

## Voice
Spoken dialogue is intentionally separate because final casting, localization and script lock are independent production decisions. Gameplay sound coverage is otherwise complete.

## QA
Music masters: 6
Ambience masters: 12
SFX masters: 98
Total audio files: 232
Wrong sample-rate masters: 0
Clipped masters: 0
Silent masters: 0
