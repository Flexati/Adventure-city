# RIOTLINE — ALL CHAT PNGS VERIFIED

This archive contains every RIOTLINE/Pixel City PNG currently present from this production conversation.

- Total PNG files: 18
- Unique image contents by SHA-256: 17
- Canonical coherent production atlases: 14
- Legacy/superseded/duplicate PNGs preserved: 4

`01`–`08` are the coherent production set. `99_LEGACY_SUPERSEDED` is preserved only so nothing generated earlier in the chat is omitted. Do not treat legacy files as canonical art direction.

Exact duplicate files are documented in `manifest.json`.
