# MASTER HANDOFF PRECEDENCE
Read `MASTER_OPUS_HANDOFF_PROMPT.md` first. This brief remains a supporting implementation note; where they differ, the Master Handoff Prompt takes precedence.

# RIOTLINE — Implementation Brief for Claude Code / Opus

## Mission
Build the playable RIOTLINE project from this pack without redesigning away its identity. Treat design files as product requirements, not loose inspiration.

## First implementation target
A polished vertical slice of Chapter 1 that proves:
- responsive Kai/Zara movement;
- instant switch;
- companion AI;
- South Blocks exploration;
- one meaningful branch choice with a persistent flag;
- Robot Pizzaiolo two-phase boss;
- Vortex chase/escape beat;
- save/load of branch state;
- entitlement abstraction present but no intrusive monetization;
- audio hooks wired even when final audio file is absent.

## Architecture requirements
- Data-driven dialogue/choice nodes.
- Save schema with versioning and migration.
- Content IDs stable and human-readable.
- Art/audio lookup through manifests, not hardcoded paths scattered in gameplay code.
- Separate `StoryState`, `EntitlementState`, `SettingsState`, and `SessionState`.
- All ads behind a single service interface with a no-op implementation for premium/offline builds.
- All purchases behind entitlement service; gameplay queries entitlements, never billing SDK directly.
- No real-brand vehicle or real-city art/text.

## Choice-state API target
Suggested conceptual surface:
- `get_axis(id)`
- `modify_axis(id, delta, source)`
- `has_flag(id)`
- `set_flag(id, value, source)`
- `can_unlock(content_id)`
- `record_consequence_seen(choice_id, consequence_id)`

## Asset fallback behavior
If a final asset is missing, render an obvious development placeholder carrying the manifest ID. Never silently substitute unrelated generated art. This lets QA detect missing production content.

## Performance priorities
- stable mobile frame pacing;
- predictable memory use for 2D atlases;
- async loading between districts;
- pooled combat VFX;
- audio voice limits;
- avoid overdraw-heavy full-screen transparent effects.

## QA gates for every chapter
1. Complete with Kai player / Zara companion.
2. Complete with Zara player / Kai companion.
3. Both major branch outcomes persist after restart.
4. No choice produces softlock.
5. Boss telegraphs readable with sound off.
6. Boss telegraphs audible with reduced effects.
7. Monetization disabled build completes identically.
8. Premium entitlement never loses access offline after validated restoration strategy.
9. Touch targets and subtitles pass accessibility review.
10. No obsolete strings: Pixel City, Peugeot, Milano, Duomo.

## Do-not-do list
- Do not rebuild as pixel-art-only.
- Do not turn Rookside into cyberpunk Night City imitation.
- Do not convert consequences back into +10% temporary bonuses only.
- Do not insert ads into bosses/dialogues.
- Do not generate new character looks without updating the locked master reference.
- Do not invent licensed music or recognizable copyrighted character designs.
