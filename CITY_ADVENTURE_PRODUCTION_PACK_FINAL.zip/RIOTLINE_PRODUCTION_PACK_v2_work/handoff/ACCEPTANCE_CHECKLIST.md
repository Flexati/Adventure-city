# RIOTLINE — Acceptance Checklist

## Brand
- [ ] RIOTLINE title used consistently.
- [ ] Rookside is fictional and geographically non-specific.
- [ ] Vortex VX-3 has no real manufacturer identifiers.
- [ ] Visual direction is modern illustrated 2D.

## Narrative
- [ ] Every chapter contains at least one persistent meaningful choice.
- [ ] At least two later consequences are linked to each major choice.
- [ ] No morality meter shown.
- [ ] Regista clues are foreshadowed before finale.
- [ ] Ending epilogues are assembled from state, not a single binary branch.

## Gameplay
- [ ] Kai and Zara both feel complete as player characters.
- [ ] Companion AI is useful but not dominant.
- [ ] Switch works during movement and combat without state corruption.
- [ ] Vortex is used as gameplay, not only scenery.
- [ ] New powers reopen old-city interactions.

## Art
- [ ] No character proportion drift between animation sheets.
- [ ] Every major move has a social-ready key pose.
- [ ] Effects remain readable over all district backgrounds.
- [ ] Marketing art matches in-game character design.

## Audio
- [ ] Main motifs are recognizable across multiple tracks.
- [ ] Every boss attack has a unique telegraph.
- [ ] Loops are seamless where required.
- [ ] Dialogue remains intelligible over music/SFX.

## Monetization
- [ ] `full_game_unlock` and `remove_ads` are entitlement-driven.
- [ ] Ads can be globally disabled without gameplay changes.
- [ ] No ad appears during bosses, important dialogue or choice moments.
- [ ] Accessibility is never monetized.
- [ ] Story flags cannot be purchased.

## Shipping hygiene
- [ ] No obsolete Pixel City references.
- [ ] No Peugeot references.
- [ ] No Milan/Duomo references.
- [ ] Missing assets are explicitly reported, never disguised.
- [ ] Save migrations tested before changing schema.
