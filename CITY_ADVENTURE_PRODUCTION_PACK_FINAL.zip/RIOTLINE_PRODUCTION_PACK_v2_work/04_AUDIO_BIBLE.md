# RIOTLINE — Audio Bible

## Sonic identity
Urban, playful, kinetic and slightly unruly. Avoid generic retro chiptune as the dominant language. The soundtrack can borrow punchy electronic percussion, bass, processed guitar, handclaps, brass/synth stabs and warm melodic motifs, with occasional lo-fi neighborhood texture.

## Main motifs
- **Duo motif:** short two-part call-and-response melody; one phrase “precise,” one phrase “explosive.”
- **Vortex motif:** three-note engine-like rise that can be played by bass/synth/brass.
- **Regista motif:** rigid four-beat pulse with tape-stop/cut edits and frame-click percussion.

## Music package
- Main Title / RIOTLINE theme.
- Garage/Hub daytime loop.
- Garage/Hub night variation.
- South Blocks exploration.
- Robot Pizzaiolo boss.
- School Belt exploration.
- Prof. Zombie boss.
- Switchyard Park exploration.
- Drago-Drone boss.
- Garden Estate party + crisis variation.
- Robot Grandmother boss.
- Ringroad driving theme.
- Motorcyclist miniboss.
- Inflatable Dragon boss.
- Mall exploration.
- Giant Gelato boss.
- Quiet City desaturated finale loop.
- Broadcast Core ascent.
- Regista phase 1/2/3 suite.
- Final Vortex aerial chase.
- Standard epilogue.
- Golden Outtake epilogue.
- Stingers: victory, fail, choice lock, clue found, Duo max, chapter complete.

## SFX families
Kai: wrench, pen strokes, word projectile, cut, parry cloth snap, rewrite.
Zara: shield pipe, hand hits, stomp, shaka charge, scream waves, gigantism.
Duo: switch pop, meter charge, finisher impacts.
Vortex: engine idle, start, rev, burnout, tire skid, door, horn, suspension, anti-gravity hum.
World: footsteps by material, doors, vending, mall ambience, school ambience, traffic beds, park beds, rain optional.
UI: focus, confirm, cancel, tab, locked choice, unlock, purchase success/fail, ad-reward confirmation.
Bosses: unique telegraphs must be audible before attacks.

## Voice strategy
Full VO is optional. Recommended launch scope is **barks + signature lines + boss reactions**, with subtitles carrying long dialogue. This controls size, localization cost and repetition fatigue.

## Technical rules
- Export music masters lossless, then runtime compressed copies.
- Loop metadata documented per track.
- SFX normalized by category, not indiscriminately to same loudness.
- Duck music under critical dialogue and accessibility narration.
- Never tie gameplay-critical timing solely to sound.
