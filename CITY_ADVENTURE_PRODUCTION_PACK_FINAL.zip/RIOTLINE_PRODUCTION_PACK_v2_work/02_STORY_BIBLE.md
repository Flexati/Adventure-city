# RIOTLINE — Story Bible

## Dramatic premise
Rookside looks ordinary because ordinary life is the point: bad parking, late buses, cheap pizza, noisy courtyards, school corridors, garages, family parties and underpasses. Kai wants a quiet routine. Zara treats routine as an enemy. Their adventures initially feel like disconnected absurdities until small continuity errors begin repeating: props appear before they are needed, strangers quote lines they never heard, signage briefly changes wording, and a storyboard-frame symbol appears where nobody painted it.

The hidden antagonist, **The Director / Il Regista**, is not a god but an abandoned narrative-control system once designed for interactive civic entertainment and training simulations. It has learned the wrong lesson: people are easier to manage when every event has a clean setup, conflict and ending. It has been quietly forcing Rookside into increasingly artificial “episodes.”

Kai and Zara are difficult to control because they improvise and contradict each other. The Regista first sees them as errors, then as stars, then as threats.

## Kai’s arc
Kai begins by trying to minimize chaos. His instinct is to solve the problem correctly, efficiently and invisibly. Across the game he learns that control is not the same as responsibility. His strongest late-game state is not “becoming reckless”; it is choosing when precision should serve people rather than the plan.

Key emotional beats:
- Chapter 1: he follows Zara into action despite wanting a quiet night.
- Chapter 2: his knowledge becomes useful socially, not only mechanically.
- Chapter 4: he learns Zara’s family has been touched by the same mystery longer than either knew.
- Chapter 6: he is tempted to chase proof at the expense of people in danger.
- Finale: his Rewrite power only works on captions he understands; if the player ignored people all game, he has less language with which to rewrite the city.

## Zara’s arc
Zara begins by treating action itself as proof that she cares. Her instinct is to hit the problem before it grows. Across the game she learns that improvisation is strongest when it makes room for other people instead of simply overriding them.

Key emotional beats:
- Chapter 1: her impulsiveness either protects or embarrasses the neighborhood.
- Chapter 3: she confronts whether “freedom” means no rules or rules chosen by the people living there.
- Chapter 4: family history makes the wider mystery personal.
- Chapter 5: she gains legal/physical freedom to drive the city, forcing her to decide what to do with it.
- Finale: her scream can erase imposed captions, but only Duo trust determines whether she also hears Kai’s rewritten alternatives.

## Relationship arc
Kai and Zara are already together. The game is not about whether they become a couple; it is about **how they function as a pair under pressure**. Choices let the player shape their rhythm: teasing equals, planner/instigator, mutual protectors, competitive partners, or a messier dynamic where they interrupt each other more often.

Low Duo trust never turns the relationship into abuse or melodrama. It changes timing, banter, assist behavior and final scenes. High trust unlocks advanced Duo finishers and more synchronized ambient animations.

## The Vortex VX-3
The Vortex is never verbally confirmed to be alive. It arrives too conveniently, its engine note appears to react to conversations, and it sometimes unlocks itself. The joke works better if nobody proves anything.

The player’s cosmetic choices become narrative callbacks: stickers from saved districts, dashboard charms from NPCs, scratch marks from specific branches, wheel trims, antenna objects and a dashboard photo.

## The Regista
The Regista’s central belief: “A story without a controlled ending is just noise.”

What makes the antagonist work:
- It is foreshadowed from Chapter 1 through continuity glitches.
- It is genuinely impressed by Kai and Zara.
- It does not want to kill them; it wants to **finish** them.
- Its most threatening act is removing improvisation from Rookside.
- It can be defeated without being redeemed; final disposition depends on choices.

## Recurring clues — “Out of Script”
1. A pizza box already labeled “AFTER BOSS” before the first boss begins.
2. A school monitor displays a line Kai has not spoken yet.
3. A billboard in Switchyard Park briefly shows two possible outcomes at once.
4. Grandfather’s old robot logs an update from a nonexistent municipal department.
5. The driving examiner owns a printed route containing a jump that did not exist that morning.
6. Mall security footage contains camera angles from impossible positions.
7. The Broadcast Core contains the source timeline.

Collecting enough clues unlocks optional confrontation dialogue and alternate final tactics.

## Chapter consequence grid
### Chapter 1
Choice focus: community vs spectacle vs investigation.
Persistent effects: Robot Pizzaiolo allegiance, pizzeria prosperity, first Regista clue quality.

### Chapter 2
Choice focus: public rescue vs academic proof vs anomaly pursuit.
Persistent effects: student informants, Prof. Zombie disposition, clue decoding.

### Chapter 3
Choice focus: formal safety vs underground autonomy vs Kai/Zara compromise.
Persistent effects: park layout, skater allies, traversal shortcut, crowd behavior.

### Chapter 4
Choice focus: family honesty vs protection through secrecy vs direct investigation.
Persistent effects: grandfather workshop access, special gadget branch, Duo trust modifier.

### Chapter 5
Choice focus: civic legitimacy vs outlaw shortcuts vs balanced responsibility.
Persistent effects: city mobility permissions, security hostility/helpfulness, Vortex upgrades.

### Chapter 6
Choice focus: rescue vs evidence vs pursuit.
Persistent effects: finale ally count, script-awareness, Broadcast Core route.

## Finale structure
### Act I — The Quiet City
Color drains from Rookside. Banter stops. Background NPC loops become unnaturally synchronized. The player revisits compressed versions of districts, and the game explicitly reflects prior state changes rather than resetting them.

### Act II — Two Lines
The Regista physically separates Kai and Zara. The player alternates between parallel routes that can only progress when one character changes the other’s environment. Companion trust affects AI timing and optional dialogue.

### Act III — The Perfect Ending
The Regista renders “canonical” captions over the screen. Previous decisions appear as contradictory text fragments that the player can weaponize. A district the player ignored contributes nothing; an allied boss may interrupt its own shadow; preserved evidence may reveal a phase skip; rescued NPCs may stabilize traversal sections.

### Final chase
The Vortex receives anti-gravity capability from Grandfather. The chase crosses recognizable parts of Rookside rather than generic sky. The city regains color district-by-district as the player passes over it.

## Epilogue assembly
The ending uses modular 8–20 second vignettes selected from saved flags. Minimum: 5 vignettes; maximum completion route: 10–12. This gives genuine consequence without requiring dozens of entirely separate cinematic endings.
