# Conversion Notes — Pixel City → RIOTLINE

- Pixel City renamed **RIOTLINE**.
- Real Milan/Duomo geography removed; setting replaced by fictional **Rookside**.
- Peugeot 306 replaced by fictional **Vortex VX-3**.
- Mandatory 16-bit pixel-art direction replaced by modern illustrated 2D direction.
- Dialogue-only minor choices replaced by persistent branching consequences.
- Ending changed from mostly completion-gated variants to modular epilogues driven by world state.
- Regista foreshadowing expanded across all chapters.
- City districts now visibly react to player choices.
- Art, audio and monetization receive dedicated production specs.
- Monetization prepared as entitlement-driven and configurable instead of hardwired.
