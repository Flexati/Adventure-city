# RIOTLINE — Visual Asset Generation Prompts

These prompts preserve the established RIOTLINE visual direction: modern illustrated 2D, clean premium comic-game rendering, crisp cel shading, strong silhouettes, expressive poses, mobile readability, no pixel art, no real-world brand logos.

## 1. Kai + Zara hero master atlas

RIOTLINE production asset atlas for a modern 2D illustrated mobile action-adventure, NOT pixel art. Clean premium comic-game rendering, crisp cel shading, strong silhouettes, expressive smear poses, urban neon accents, consistent proportions, no logos from real brands. Character A KAI: 18-year-old slim male, messy brown hair, rectangular glasses, navy/blue street jacket, dark trousers, practical sneakers, blue energy handwriting motif, intelligent reluctant expression. Character B ZARA: young adult female, long vivid red hair, green eyes, cropped red street jacket over black practical outfit, athletic stance, red shockwave motif, fearless mischievous expression. Arrange as a professional game-production master sheet with clearly separated full-body poses: neutral turnaround front/side/back/3-4, idle, run key pose, jump, dodge, hit, light attack, special attack, duo victory; also 5 facial portrait expressions for each. Consistent identity in every pose. Flat bright green studio background only, no scenery, no text labels, no shadows touching neighboring poses, generous spacing for extraction.

## 2. Boss + NPC atlas

RIOTLINE production boss and NPC master atlas, modern illustrated 2D action-adventure, premium cel-shaded comic game art, NOT pixel art, same visual language across every design, strong silhouettes, urban absurdist comedy. Include clearly separated full-body concept/animation key poses for: polite ROBOT PIZZAIOLO with chef cap and pizza-disc arms; eccentric PROF ZOMBIE academic with quiz projector; DRAGO-DRONE mechanical flying dragon; cheerful dangerous GRANDPA inventor with gadget glove; KAI'S MOTHER practical urban parent; ROBOT DELLA NONNA toy-like party robot with balloons; MOTOCYCLIST helmet thief; inflatable dragon boss; giant three-flavour gelato creature; IL REGISTA as monochrome broadcast-screen entity with typographic energy. For each boss show neutral, attack, hit/stun, defeat key pose when space permits. Flat bright green studio background only, no text, no scenery, generous spacing, production-ready extraction layout.

## 3. Vortex VX-3 vehicle atlas

RIOTLINE vehicle production atlas, modern illustrated 2D comic-action game art, premium clean cel shading, NOT pixel art. Design the VORTEX VX-3, a completely fictional compact white late-1990s-inspired hatchback with distinctive original body shape, angular black trim, subtle blue-red duo accents, no resemblance badges or real manufacturer marks. Show isolated views and action keyframes: front 3/4, rear 3/4, side, top-ish 3/4, garage idle, accelerating, hard brake, burnout with tire smoke, cosmetic dented state, summon-dash energy entrance, antigravity hover with improvised gadget hardware, airborne chase pose. Also show three tasteful cosmetic skin variants. Flat bright green studio background only, no scenery, no text, generous spacing for extraction.

## 4. Rookside environment atlas

RIOTLINE environment art atlas for a modern illustrated 2D side-view / 2.5D mobile action-adventure, premium comic-book urban rendering, NOT pixel art. Fictional city ROOKSIDE: peripheral lived-in urban districts, grounded rather than cyberpunk. Create separated wide environment plates / parallax-ready scene concepts for South Blocks apartment streets with pizzeria; School Belt courtyard and underpass; Switchyard Park with skate ramps; eccentric grandfather Garden Estate; Ringroad and driving school; indoor/outdoor Mall with freezer corridor; Broadcast Core tower district; cluttered garage hub for the Vortex VX-3. Cohesive architecture, posters and signage with invented brands only, strong navigation landmarks, day/night variants where helpful. No real city landmarks. Arrange each location as a clean bordered production panel, no text labels.

## 5. UI + VFX atlas

RIOTLINE game UI + VFX production atlas, modern illustrated 2D comic action adventure, clean premium mobile readability, NOT pixel art. On a dark neutral presentation canvas create separate production elements: health bars for Kai blue and Zara red; duo meter; minimal choice-dialogue cards; map node icon language; inventory tiles; shop tiles; settings/accessibility icon family; pause/results panels; full-game unlock card; optional rewarded-ad card that feels non-intrusive. Also isolated VFX sprites: blue handwritten laser strokes, red sonic shockwaves, duo interference burst, monochrome Regista caption distortion, impact typography shapes without readable words, dust/debris, tire smoke, burnout sparks, antigravity rings, pickup sparkle. No real logos, no lorem ipsum, use abstract placeholder glyphs instead of text where needed.

## 6. Marketing art board

RIOTLINE premium mobile game marketing art board, modern illustrated 2D comic-action style, NOT pixel art. Hero composition: Kai and Zara back-to-back in dynamic urban street action, Vortex VX-3 drifting behind them, Rookside apartment blocks and broadcast tower, absurd bosses looming as silhouettes, blue and red energy colliding with monochrome Regista distortion. Original distinctive visual identity, high contrast readable thumbnail, viral social-media energy without copying existing franchises. Include alternate crop-safe compositions in one board for square app icon concept, 16:9 feature graphic, and 9:16 vertical social poster. No real-world brand marks, no text.

## Integration rule

Use the supplied local visual-direction reference as the style anchor. Opus may improve composition, anatomy, animation readability, atlas packing, pivots and export sizes, but must preserve character identity, silhouette language, blue/red duo coding, fictional vehicle branding and the non-pixel illustrated style.
