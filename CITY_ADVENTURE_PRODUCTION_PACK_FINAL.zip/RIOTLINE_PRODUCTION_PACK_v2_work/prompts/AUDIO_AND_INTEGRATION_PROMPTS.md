# RIOTLINE — Audio + Integration Prompts

## Audio direction prompts

### Main theme
RIOTLINE main theme, instrumental game soundtrack, 118 BPM, modern urban action-comedy with emotional heart. Punchy live drums, distorted bass, bright synth arpeggios, playful brass stabs, electric guitar accents, memorable 4-note blue/red duo motif that can be reused across the score. Starts restrained, grows heroic, ends with a clean logo sting. No vocals, no copyrighted melodies, premium mobile/console game mix.

### Rookside hub
RIOTLINE Rookside hub music, instrumental, 92 BPM. Lived-in fictional peripheral city in early evening: warm electric piano, muted guitar, dry hip-hop drums, small analog synth motif from the RIOTLINE main theme, subtle city pulse, playful but grounded, loop-friendly, no vocals, no cinematic bombast.

### Duo action cue
RIOTLINE general combat / traversal action cue, instrumental, 132 BPM. Agile comic-book action, tight breakbeat drums, bass guitar, energetic synth stabs, blue handwritten-energy motif answered by red sonic-shockwave motif, room for SFX, seamless-gameplay feel, no vocals, original melody.

### Boss suite
RIOTLINE boss battle suite, instrumental, 145 BPM. Absurd dangerous comedy with mechanical percussion, distorted bass, brass hits, synth sirens and stop-start rhythmic jokes; three escalating phases, memorable motif, still genuinely exciting rather than novelty music. No vocals, original game score.

### Il Regista finale
RIOTLINE final boss music for IL REGISTA, instrumental. Begins severe monochrome and controlled at 108 BPM with prepared piano, low strings, glitch pulses and broadcast-static rhythm; halfway the Kai/Zara motif breaks the structure, tempo lifts toward 150 BPM, color and rock drums explode in, ending triumphant and chaotic. No vocals, original.

### Epilogue
RIOTLINE epilogue / chapter-complete music, instrumental, 84 BPM. Warm intimate reprise of the main duo motif on clean guitar, soft electric piano and understated drums, bittersweet-comic rather than sentimental, ending with a tiny playful musical wink. No vocals, original.

## SFX direction

- kai_laser_pen: fast blue energy pen stroke; electric zip + paper scratch + concise impact pop.
- zara_megablast: red sonic charge into wide WHUMP with debris tail.
- duo_switch: blue/red crossing whoosh + comic snap + micro-bass impact.
- duo_max: two rising interlocked tones + interference sparkle + confident harmonic impact.
- vortex_burnout: compact hatchback rev -> tire squeal -> gravel spray -> launch.
- vortex_antigrav: latch clicks + improvised gadget hum + magnetic rise + unstable flutter.
- ui_confirm: tactile click + bright two-note confirmation chime.
- choice_lock: paper/card snap + low decisive pulse + faint consequence glitch.
- clue_found: curious sparkle + short rising phrase + tiny mechanical click.
- regista_glitch: CRT crackle + reversed paper rip + digital burst + short sub hit.
- robot_pizza_throw: frisbee whoosh + oven-door clank + crispy impact tick.
- victory_sting: short two-bar heroic-comic sting under 3 seconds.

## Opus integration mandate

1. Treat the shipped RIOTLINE package as the authoritative starting baseline.
2. Import and wire the included audio and visual assets first; do not discard them before a working pass exists.
3. Use manifests as the initial source of paths and semantic roles.
4. Validate pivots, atlas slicing, animation frame timing, transparency, collision bounds, audio loudness, loop points and memory footprint.
5. After baseline integration, perform a second critical pass and improve any weak asset, animation, sound, UI or gameplay implementation if the replacement is objectively more coherent and robust.
6. Preserve RIOTLINE identity: Kai + Zara duo, Rookside, Vortex VX-3, modern illustrated 2D, blue/red energy language, absurd-action tone, consequential choices and clean monetization boundaries.
7. Never sacrifice stability for spectacle: no softlocks, broken saves, missing references, inaccessible routes, dead buttons or monetization interruptions during boss fights / key dialogue / narrative choices.
8. Every replacement must update manifests and tests so the package remains traceable.
