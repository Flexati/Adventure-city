# RIOTLINE — Package Manifest

This package intentionally contains Markdown documentation alongside JSON manifests, local visual references and local audio assets.

## Markdown documents

- 00_README.md
- 01_RIOTLINE_GDD_v3.md
- 02_STORY_BIBLE.md
- 03_ART_BIBLE.md
- 04_AUDIO_BIBLE.md
- 05_MONETIZATION_AND_ENTITLEMENTS.md
- CHANGELOG_FROM_PIXEL_CITY.md
- handoff/ACCEPTANCE_CHECKLIST.md
- handoff/MASTER_OPUS_HANDOFF_PROMPT.md
- handoff/OPUS_IMPLEMENTATION_BRIEF.md
- prompts/VISUAL_ASSET_GENERATION_PROMPTS.md
- prompts/AUDIO_AND_INTEGRATION_PROMPTS.md
- source/PIXEL_CITY_ORIGINAL_SOURCE.md

## Machine-readable specs

- manifests/asset_manifest.json
- manifests/audio_manifest.json
- manifests/content_manifest.json
- specs/choice_system.json
- audio/LOCAL_AUDIO_MANIFEST.json

## Local media

- assets/reference/visual_direction_reference.png
- audio/music/*.wav + *.ogg
- audio/sfx/*.wav + *.ogg

## External generated visual atlases

Six additional visual atlases were generated through an external creative tool during production (heroes; bosses/NPC; Vortex VX-3; Rookside environments; UI/VFX; marketing). Because that service did not expose a reliable filesystem transfer path into this package, they are not falsely listed as local files. Their reproducible prompts are included in prompts/VISUAL_ASSET_GENERATION_PROMPTS.md.
