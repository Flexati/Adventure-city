# RIOTLINE — Production Pack

This package converts the original Pixel City concept into the current RIOTLINE direction.

## Locked creative direction
- Title/brand: **RIOTLINE**.
- Setting: **Rookside**, a fully fictional peripheral urban city; no real northern-Italian city references.
- Visual language: **modern illustrated 2D**, not mandatory pixel art. Bold silhouettes, clean shapes, expressive smear frames, comic-impact typography, high readability on mobile.
- Duo: **Kai + Zara**; instant switching and companion AI remain core.
- Vehicle: **Vortex VX-3**, a fictional compact white hatchback and third protagonist.
- Tone: urban comedy, slapstick, romance, escalating absurdity, emotional sincerity underneath.
- Narrative: player choices create persistent consequences; no simple good/evil meter.
- Monetization: architecture-ready but configurable; monetization must never interrupt bosses, major dialogue, or important choice moments.
- Audio: original music/SFX/voice package planned as first-class content.

## Package status
The package contains a production-ready **design and integration specification** plus the existing visual-direction image. It does **not** pretend that every final sprite, animation, SFX, music track, or voice line has already been rendered. Those missing deliverables are explicitly enumerated in the manifests so an art/audio generation pass can produce them deterministically.

## Recommended consumption order for Claude Code / Opus
1. `01_RIOTLINE_GDD_v3.md`
2. `02_STORY_BIBLE.md`
3. `specs/choice_system.json`
4. `03_ART_BIBLE.md`
5. `manifests/asset_manifest.json`
6. `04_AUDIO_BIBLE.md`
7. `manifests/audio_manifest.json`
8. `05_MONETIZATION_AND_ENTITLEMENTS.md`
9. `handoff/OPUS_IMPLEMENTATION_BRIEF.md`
10. `handoff/ACCEPTANCE_CHECKLIST.md`

## Non-negotiables
Do not rename the project back to Pixel City. Do not reintroduce Peugeot, Milan, Duomo, or real-city geography. Do not convert the art direction back to retro 16-bit pixel art unless explicitly requested. Do not reduce choices to cosmetic dialogue-only branches. Do not hardwire ads into critical gameplay beats.

## Primary Claude Code / Opus entry point
Start with `handoff/MASTER_OPUS_HANDOFF_PROMPT.md`. It defines the baseline-first / improve-second workflow, asset and audio integration rules, QA gates, monetization boundaries, and permission to improve the implementation beyond the supplied design while preserving RIOTLINE's identity.
