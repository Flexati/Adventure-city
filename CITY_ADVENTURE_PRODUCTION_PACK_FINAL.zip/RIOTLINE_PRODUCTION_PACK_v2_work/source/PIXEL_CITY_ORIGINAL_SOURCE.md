# PIXEL CITY — Documento di Design Completo

*Basato su "Le Avventure Ridicole di Kai e Zara" — Versione 2.0 con gran finale esteso*

---

## 1. Visione

**Pixel City** è un action-adventure comico 2D in pixel art 16-bit, ambientato in una Milano a pixel popolata da superpoteri ribelli che emergono solo durante le avventure più idiote. Due eroi, una Peugeot 306 bianca indistruttibile, sei capitoli-livello e un gran finale segreto che chiude — e riapre — tutto.

**Tono:** slapstick anni '80, ritmo da fumetto, zero seriosità, cuore che batte.

**Pilastri di design**

1. **Il Duo è uno solo:** Kai e Zara si alternano con switch istantaneo o giocano in co-op locale. Nessuno dei due esiste senza l'altro.
2. **La 306 è il terzo personaggio:** hub mobile, veicolo, arma, checkpoint, base d'attacco.
3. **Il potere è comico:** ogni abilità ha un effetto esagerato e una gag incorporata.
4. **Livelli brevi, boss memorabili:** 10-15 minuti a capitolo, boss con 2-3 fasi e almeno un momento "ma che cavolo".
5. **Ogni vittoria finisce con un bacio:** la splash page finale di ogni capitolo è obbligatoria.

---

## 2. Personaggi e Personalità

### 2.1 Kai — "Super Penna" (18 anni)

**Aspetto:** alto, magro, capelli castani arruffati, occhiali da intellettuale. Palette blu.

**Personalità:**

- **Il cervello riluttante.** Kai vorrebbe solo una serata normale sul divano. Ogni emergenza lo coglie a metà di un sospiro. La sua frase-tipo è "Di nuovo?", detta mentre è già in piedi pronto a partire.
- **Preciso fino al ridicolo.** Prima di scagliare un Laser Penna, corregge mentalmente la grammatica di quello che sta per scrivere. Se il nemico ha un cartello con un errore di ortografia, Kai lo corregge *durante* la boss fight.
- **Romantico impacciato.** Adora Zara in modo totale e goffo: le accarezza i capelli sul divano, le prepara sorprese, e poi inciampa sui propri capelli nei momenti epici.
- **Coraggio procrastinato.** Non è mai il primo a buttarsi nella mischia — è il primo a *finire* la mischia, perché quando decide che una cosa va fatta, la fa bene.
- **Gag ricorrente:** inciampa nei dash lunghi; gli occhiali scivolano nei momenti drammatici e lui li risistema *prima* di contrattaccare.

**Stile di gioco:** distanza e precisione. Attacchi rapidi con la chiave inglese, proiettili scritti con la Laser Penna.

### 2.2 Zara — "Luce Rossa" (16 anni)

**Aspetto:** capelli rossi lunghi, occhi verdi furiosi, posa permanente con le mani sui fianchi. Palette rossa.

**Personalità:**

- **Incontenibile.** Zara non aspetta l'avventura: la provoca. Quando il telefono squilla per un'emergenza, lei sorride *malefica* prima ancora di sapere di cosa si tratta.
- **Zero paura, cento per cento improvvisazione.** Le sue strategie non esistono: esistono le sue *entrate*. Il tubo della doccia come scudo? "Mi sembrava ovvio."
- **Protettiva feroce.** Nessuno tocca Kai, la pizza del quartiere, il nonno o la sua Peugeot. In quest'ordine, a seconda della giornata.
- **Competitiva con se stessa.** Ogni boss è un record personale da battere. Dopo ogni vittoria chiede: "Hai visto quant'è stato figo? Ammetti che è stato figo."
- **Romantica esplosiva.** Il suo "Pugno dell'Amore" è letteralmente un pugno seguito da un bacio che genera un'onda d'urto. L'affetto, per Zara, è un'arma ad area.
- **Gag ricorrente:** cade da altezze improbabili e si rialza già urlando la mossa successiva; la barra dell'Urlo si scarica sempre un secondo prima del colpo di grazia (e lei urla comunque, gratis).

**Stile di gioco:** mischia e area. Tubo-scudo, urla ad onda, close combat spettacolare.

### 2.3 La Peugeot 306 Bianca — "La Bestia" (nome in codice affibbiato da Zara, mai riconosciuto da Kai)

**Personalità (sì, ha una personalità):**

- **Ridicola ma indistruttibile.** Si ammacca, si rizza, tossisce un po' di fumo bianco e riparte. Non si è mai rotta. Non si romperà mai. Il gioco non contiene nemmeno un'animazione di rottura.
- **Sempre nel posto giusto.** Parcheggiata di fianco al marciapiede, nel parcheggio della scuola, davanti al supermercato: il motore ronza piano *come se stesse già aspettando l'avventura*. Nessuno sa come ci arrivi prima di loro. Kai ha smesso di chiederselo.
- **Entrata epica garantita.** Ogni sezione in auto inizia con un burnout rumorosissimo e finisce con una frenata epica. È contrattuale.
- **Funzioni in gioco:** checkpoint mobile, hub, negozio, arma (Burnout della Peugeot), veicolo delle sezioni di inseguimento, rifugio nelle boss fight.

### 2.4 Comprimari

| Personaggio | Personalità | Ruolo in gioco |
|---|---|---|
| **Il Nonno di Zara** | Ex-inventore in pensione, ride sempre, regala gadget pericolosi ("Tieni, questo guanto l'ho fatto trent'anni fa, dovrebbe funzionare") | Fornitore di poteri (Guanto Magico, Cap. 5) e saggezza nonsense |
| **La Mamma di Kai** | Perennemente sorpresa ma mai davvero scioccata; sale sulla 306 durante gli inseguimenti commentando la guida | Passeggera sorpresa nel Cap. 2; commentatrice del finale |
| **Il Robot Pizzaiolo** | Educato, si scusa mentre ruba; indossa il cappellino con orgoglio | Boss Cap. 1; poi NPC amichevole alla pizzeria |
| **Il Prof. Zombie** | Ossessionato dai quiz di storia, vuole rubarli "per la gloria accademica" | Boss Cap. 2 |
| **Il Ladro d'Asfalto** | Ex-insegnante di ginnastica, sogna una pista da skate illegale; fair-play assoluto, autografa lo skate dopo la sconfitta | Boss Cap. 3 |
| **Il Robot della Nonna** | Regalo di 30 anni prima, "ha fame di regali"; si scioglie in coriandoli | Boss Cap. 4 |
| **Il Motociclista** | Collezionista di caschi altrui; guida benissimo e perde malissimo | Mini-boss Cap. 5 |
| **Il Gelato Gigante** | Goloso cosmico, ruba dolci, si scioglie e si ricostruisce | Boss Cap. 6 |
| **??? (Il Regista)** | *Vedi Gran Finale, sezione 6* | Boss finale segreto |

---

## 3. Mappa di Pixel City (Hub a Pixel)

### 3.1 Struttura generale

La città è una griglia a pixel divisa in **7 distretti** (6 dei capitoli + il centro), collegati dalla 306. Il viaggio rapido si sblocca per ogni distretto dopo averne sconfitto il boss. Panoramica (vista top-down semplificata):

```
                ┌──────────────────────────────┐
                │   MILANO CENTRO (Hub Nord)   │
                │  Duomo pixel + Galleria gag  │
                └──────────────┬───────────────┘
        ┌──────────────┐       │       ┌──────────────────┐
        │  QUARTIERE   ├───────┼───────┤  SCUOLA E GROTTA │
        │  (Cap. 1)    │       │       │  (Cap. 2)        │
        └──────┬───────┘       │       └────────┬─────────┘
               │        ┌──────┴──────┐         │
               │        │  GARAGE 306 │         │
               │        │  (HUB)      │         │
               │        └──────┬──────┘         │
        ┌──────┴───────┐       │       ┌────────┴─────────┐
        │  PARCO       ├───────┼───────┤  VILLA DEL NONNO │
        │  (Cap. 3)    │       │       │  (Cap. 4)        │
        └──────────────┘       │       └──────────────────┘
                ┌──────────────┴───────────────┐
                │  SCUOLA GUIDA (Cap. 5)       │
                └──────────────┬───────────────┘
                ┌──────────────┴───────────────┐
                │  SUPERMERCATO (Cap. 6)       │
                │  → ingresso ZONA FINALE      │
                └──────────────────────────────┘
```

### 3.2 I distretti in dettaglio

| Distretto | Livello | Note visive e interattive |
|---|---|---|
| **Quartiere** | Cap. 1 | Pizzeria con insegna lampeggiante, marciapiedi, il divano di casa (punto di salvataggio). La 306 è parcheggiata sul marciapiede, motore al minimo |
| **Scuola e Grotta** | Cap. 2 | Cortile scolastico, parcheggio (merendina nascosta), grotta dei fossili con portale pulsante |
| **Parco** | Cap. 3 | Skate park con rail e rampe, laghetto pixel, maxischermo dove proiettare le proprie vittorie |
| **Villa del Nonno** | Cap. 4 | Giardino con aiuole distruttibili, cancello, sala festa con tavolo delle torte |
| **Scuola Guida** | Cap. 5 | Circuito del test con coni arancioni, cortile della recita con il drago gonfiabile |
| **Supermercato** | Cap. 6 | Corsie-labirinto, reparto freezer illuminato di blu, dispensatori di Coca esplosivi |
| **Milano Centro** | Endgame | Si sblocca dopo il Cap. 6. Duomo pixel, Galleria gag, e il **Maxischermo Centrale**: porta per la Zona Finale |

### 3.3 Il Garage 306 (hub centrale)

Il garage è il cuore del gioco:

- **Negozio gadget:** potenziamenti comprati con le merendine-collezionabile.
- **Cambio outfit:** palette alternative per Kai e Zara (sbloccabili con le figurine).
- **Rigioca livelli:** ogni capitolo è riaffrontabile con i poteri già sbloccati (modalità "Remix").
- **Galleria:** le splash page dei baci conquistate, in pixel art.
- **Il banco del Nonno:** dialoghi opzionali e gadget strani.

### 3.4 Segreti diffusi

- **Una merendina nascosta per livello** (7 totali con la Zona Finale).
- **Cartelloni vivi** da distruggere: rilasciano monete e una battuta.
- **Il parcheggiatore fantasma:** un NPC che appare in un punto diverso ogni volta e commenta dove hai lasciato la 306.

---

## 4. Sistema di Dialoghi

### 4.1 Formato

- **Balloon da fumetto** sopra le teste, onomatopee integrate nel mondo (BAM, KRAK, VROOOM compaiono come sprite pixel).
- **Ritmo da banter:** mai più di una battuta ogni 3-5 secondi in combattimento, per non coprire l'azione.
- **Frasi-firma** con testo ingrandito e shake dello schermo: "Non rubare più le pizze!", "Urlo della Verità!", "Pugno dell'Amore!", "Burnout della Peugeot!", "Laser Penna!", "MEGABLAST!"

### 4.2 Player/NPC flessibile

Il giocatore controlla un personaggio; l'altro è un **NPC companion** con IA dedicata:

- **Zara-NPC:** aggressiva, si butta in mischia, urla commenti ("Lascialo a me, amore!"). Se il giocatore resta fermo più di 10 secondi, Zara si pianta con le mani sui fianchi e tamburella il piede.
- **Kai-NPC:** tattico, mantiene la distanza, copre con la Laser Penna. Se il giocatore resta fermo, sospira e si risistema gli occhiali.
- **Switch istantaneo** con un tasto, anche a mezz'aria: lo scambio genera una micro-onda d'urto (e una battuta).

### 4.3 Scelte rapide

Nei dialoghi pre-boss, il giocatore sceglie tra **2 risposte rapide**. Cambiano la gag di introduzione del boss e danno bonus minori (es. +1 merendina, +10% barra Duo iniziale). **Mai il finale:** la storia è una, le risate cambiano.

### 4.4 Esempi di dialogo (personalità in azione)

**Premessa (Cap. 1, sul divano):**

> **KAI:** *(accarezzandole i capelli)* "…e quindi il reality è finito con due che si sposano e uno caduto nella piscina."
> **ZARA:** *(bocca piena di patatine)* "Cinema. Puro cinema."
> *(squillo del telefono)* **VOCE:** "Emergenza nel quartiere! Un robot ha rubato tutte le pizze della pizzeria sotto casa!"
> **KAI:** *(sospiro cosmico)* "Di nuovo?"
> **ZARA:** *(sorriso malefico, già in piedi)* "Finalmente una serata da eroi, amore mio!"
> *(taglio: la 306 bianca ronza piano sul marciapiede)*
> **KAI:** "…quella macchina mi mette ansia. Era già accesa."
> **ZARA:** "È entusiasta. Lasciala vivere."

**Banter in combattimento (Cap. 1):**

> **ZARA:** "Kai! La pizza! PRENDI LA PIZZA!"
> **KAI:** *(afferra la pizza volante con la chiave inglese)* "Recuperata. E tiepida. Sono un professionista."
> **ZARA:** "Hai usato una chiave inglese come paletta."
> **KAI:** "L'improvvisazione è una forma d'arte."

**Pre-boss (Cap. 2, scelta rapida):**

> **PROF. ZOMBIE:** "Consegnatemi il quiz di storia e nessuno si farà male… accademicamente."
> *(Scelta A)* **ZARA:** "Il quiz resta. Tu torni nella tomba. MEGABLAST!" *(+10% barra Duo)*
> *(Scelta B)* **KAI:** "Domanda bonus: chi ha firmato la pace di Vestfalia?" *(il boss esita 3 secondi: finestra di attacco gratuita)*

**Momento finale tipo (Cap. 6):**

> **KAI:** "Ogni giorno è una nuova avventura ridicola… e non ti cambierei mai per nulla al mondo."
> **ZARA:** "Allora preparati, amore mio… la prossima settimana c'è la festa di Halloween di tua madre. Saranno ancora più idioti."
> **KAI:** "…di nuovo?"

### 4.5 Struttura dati

Albero dialoghi in JSON: ogni nodo ha `id`, `speaker`, `testo`, `condizione` (capitolo, potere sbloccato, HP del boss), `banter_tag` (caduta, combo, vittoria, fuga). Le frasi-firma sono eventi speciali con flag `signature: true` che attivano shake e zoom.

---

## 5. I Sei Capitoli — Livelli, Boss e Poteri

Ogni capitolo segue la stessa spina dorsale: **Premessa comica → Livello d'azione → Boss a fasi → Sezione Peugeot 306 → Splash page del bacio**. Ognuno introduce almeno un potere nuovo e contiene 2-3 gag slapstick scriptate.

### Capitolo 1 — "La Pizza Ladra" (Distretto: Quartiere)

- **Livello:** inseguimento per i marciapiedi del quartiere. Pizze volanti da recuperare (collezionabili di livello), tombini che esplodono, piccioni pixel ostili.
- **Boss: ROBOT PIZZAIROLO.**
  - *Fase 1 (Con Cappellino):* lancia pizze-frisbee a schermo intero; si schivano o si rispediscono col Tubo-scudo.
  - *Fase 2 (Senza Cappellino):* perde il cappellino, diventa il doppio veloce e si scusa il doppio ("Mi dispiace tantissimo!").
  - *Debolezza:* rimbalzare una pizza con il tubo e colpirlo, poi **Shaka Stun** di Zara: "Non rubare più le pizze!"
- **Sezione 306:** fuga dal robot ancora in piedi, partenza esagerata, drifting tra i cassonetti.
- **Poteri sbloccati:** Chiave Inglese (Kai), Tubo-Scudo (Zara), **Shaka Stun**, **Chiamata Peugeot** (dash evocando la 306).
- **Splash page:** bacio sotto le stelle mangiando la pizza in regalo.
- **Gag scriptate:** Kai inciampa su un marciapiede di 3 cm; Zara cade da un'altalena e si rialza già con lo shaka pronto; il robot si inchina mentre viene distrutto.

### Capitolo 2 — "La Gita Scolastica Infernale" (Distretto: Scuola e Grotta)

- **Livello:** grotta dei fossili con trappole-portale, poi cortile e parcheggio della scuola. I fossili si animano come nemici minori.
- **Boss: PROF. ZOMBIE.**
  - Meccanica a quiz: il boss pone domande di storia e compaiono tre bersagli; colpire quello giusto infligge danno, quello sbagliato evoca un fossile nemico.
  - **Doppio boss a sorpresa:** alla sua sconfitta, Zara fa esplodere per sbaglio la colonnina elettrica di un cartellone — nasce il **CARTONATO GIGANTE**, inseguimento nel parcheggio.
- **Sezione 306:** fuga in giardino/parcheggio con a bordo *anche la mamma di Kai*, sorpresa, che commenta la guida ("Tesoro, il limite è 50").
- **Poteri sbloccati:** **Laser Penna** (Kai: scrive parole-proiettile, "BAM" esplode, "PORTA" apre), **MEGABLAST** (Zara: urlo che abbatte muri e chiude portali).
- **Splash page:** bacio sul tetto della 306 parcheggiata in mezzo alle aiuole.
- **Gag scriptate:** Kai scrive la parola sbagliata e si esplode da solo (danno cosmetico); Zara urla il nome della mossa prima di averla imparata e non succede nulla; la mamma di Kai applaude al momento sbagliato.

### Capitolo 3 — "Lo Skateboard Volante e il Ladro d'Asfalto" (Distretto: Parco)

- **Livello:** skate park a scorrimento con rail, rampe e sezioni a gravità ridotta (grazie alla bibita energizzante di Zara).
- **Boss: DRAGO-DRONE.**
  - *Fase 1:* drone con fuochi d'artificio a ventaglio.
  - *Fase 2 (si riavvia):* "modalità drago volante", soffi infuocati a ondate.
  - *Fase 3:* inseguimento aereo sopra il parco.
  - *Debolezza:* **Penna-Forbici** per tagliare i cavi, **Urlo della Verità** per abbatterlo.
- **Sezione 306:** burnout rumoroso nel vialetto, autostrada di evasione creata scrivendo laser sull'asfalto + urla esplosive.
- **Poteri sbloccati:** **Anti-Gravità** (doppio salto/volo breve, entrambi), **Penna-Forbici** (Kai), **Urlo della Verità** (Zara). Skateboard come mezzo di trasporto in-livello.
- **Splash page:** bacio in cima al maxischermo del parco, che proietta la loro vittoria in differita.
- **Gag scriptate:** la bibita energizzante fa venire il singhiozzo a Zara (le urla diventano "URL-hic-O"); Kai atterra in verticale sulla tavola e scivola fuori scena; il ladro restituisce lo skate e lascia l'autografo *sul casco di Kai*.

### Capitolo 4 — "La Festa di Compleanno del Nonno e il Robot di Plastica" (Distretto: Villa del Nonno)

- **Livello:** casa e giardino durante la festa. Sopravvivere alle ondate di palloni esplosivi proteggendo il tavolo delle torte (barra "Integrità Torta").
- **Boss: ROBOT DELLA NONNA.**
  - Lancia palloni-proiettile in pattern da sparatutto.
  - Meccanica "Fame di Regali": i regali raccolti nel livello si possono lanciare per distrarlo (stun di 5 secondi).
  - *Finale:* il **Pugno Duo** lo scioglie in coriandoli.
- **Sezione 306:** giro pazzesco nel giardino, la 306 slaloma tra le aiuole mentre il robot insegue.
- **Poteri sbloccati:** **Scudo Maglietta** (Kai: parry che rimanda i proiettili), **Pugno Duo** (prima mossa di coppia caricata).
- **Splash page:** bacio in pista da ballo mentre il nonno ride: "Mia nipote ha ancora il cuore di un'eroina."
- **Gag scriptate:** Kai usa la maglietta come scudo e resta in canottiera imbarazzato per mezzo livello; Zara si arrampica sul tavolo e rovescia solo *una* torta (quella del nonno, che la mangia da terra); il robot canta "tanti auguri" in modalità minacciosa.

### Capitolo 5 — "La Scuola di Guida e il Drago di Plastica" (Distretto: Scuola Guida)

- **Livello:** circuito del test di guida. Lo scooter si trasforma in veicolo volante grazie al Guanto Magico del nonno. Sezioni aeree tra i palazzi pixel.
- **Mini-boss: IL MOTOCICLISTA** (vuole rubare il casco). Duello su due ruote nel circuito.
- **Boss: DRAGO GONFIABILE.**
  - Prende vita dopo il test, nel cortile della recita.
  - Si sgonfia a ogni colpo subito e si rigonfia per rimbalzare come proiettile: bisogna colpirlo mentre è sgonfio.
  - *Debolezza:* **Freno Antigravità** per inchiodarlo a terra + combo Duo.
- **Sezione 306:** parcheggiata davanti alla scuola, giro pazzesco tra le aiuole, frenata epica sotto il drago ancora in volo.
- **Poteri sbloccati:** **Freno Antigravità** (Zara: stop istantaneo/atterraggio morbido), **Veicolo Volante** (sezioni aeree), **Patente da Eroe** (sblocca la **guida libera della 306** in tutta la città).
- **Splash page:** bacio sul balcone mentre tutta la città pixel li guarda (e qualcuno fa la ola).
- **Gag scriptate:** Zara supera il test di guida *durante* la boss fight e l'esaminatore timbra la patente terrorizzato; Kai guida "come un pazzo" cioè a 32 km/h rispettando tutti i segnali; il drago sgonfiato si incastra in un lampione.

### Capitolo 6 — "Il Supermercato Mostruoso" (Distretto: Supermercato)

- **Livello:** corsie-labirinto con modalità **Gigantismo** a tempo (scala x2: si sfondano gli scaffali). Il reparto freezer è una zona scivolosa.
- **Boss: GELATO GIGANTE.**
  - Ruba dolci dalle corsie per curarsi; va interrotto.
  - Si scioglie e si ricostruisce: ogni ricostruzione cambia gusto e pattern (vaniglia = lento e pesante, fragola = veloce e appiccicoso, cioccolato = proiettili a scaglie).
  - *Debolezza:* **Supervitamine** di Kai per sgonfiarlo + schiuma dei dispensatori di Coca fatta esplodere dalle urla di Zara.
- **Sezione 306:** burnout epico nel parcheggio del supermercato, carico di regali di Natale sul tetto, inseguimento finale col gelato.
- **Poteri sbloccati:** **Gigantismo** (Zara, a tempo), **Supervitamine** (Kai: buff di gruppo), **Burnout della Peugeot POTENZIATO** (mossa Duo definitiva).
- **Splash page:** bacio davanti al frigo pieno di regali, la 306 sullo sfondo con il motore al minimo.
- **Gag scriptate:** Kai gigante non passa dalle porte e deve rimpicciolire al momento sbagliato; Zara scivola nel freezer per 40 metri in posa eroica; un cassiere NPC continua a battere scontrini durante tutta la boss fight.

---

## 6. GRAN FINALE — "La Notte dei Cattivi Ridicoli" (Capitolo Segreto 7)

*Si sblocca completando il Cap. 6 con tutte e 7 le merendine raccolte. La storia si allunga: niente "fine", solo "continua".*

### 6.1 Premessa del finale

La sera dopo il supermercato, tutta Milano pixel si spegne. Sul **Maxischermo Centrale** compare un volto fatto di pixel spenti: **IL REGISTA**, l'entità che ha "diretto" ogni avventura idiota dall'inizio — il robot pizzaiolo, il portale, il drone, tutto. La sua accusa:

> **IL REGISTA:** "Sei capitoli. Sei vittorie. Sei baci finali. Sapete perché le vostre avventure sono così ridicole? Perché le ho *scritte* io. E adesso voglio il finale che merito: uno serio. Addio, risate."

Il Regista raduna **tutti i boss sconfitti** in una squadra, la **Lega dei Cattivi Ridicoli**, e ruba la cosa più importante di Pixel City: **il colore**. La città diventa in scala di grigi, i banter si spengono, le onomatopee cadono a terra come lettere morte. È la cosa più vicina a una minaccia seria che il gioco si conceda — per poi riderci sopra fino all'ultimo frame.

### 6.2 Struttura del livello finale

**Atto 1 — Milano in bianco e nero.** Hub cittadino desaturato: attraversare i 6 distretti in modalità ridotta (ogni distretto è un mini-livello di 3 minuti che riusa una meccanica del suo capitolo). In ogni distretto si recupera un **colore primario** sconfiggendo di nuovo un boss, ora alleato del Regista ma… annoiato dalla serietà. Ogni boss riportato al ridicolo *diserata* e si unisce alla resistenza:

- Robot Pizzaiolo: si ribella per primo. "Un finale serio? Senza pizza? Inaccettabile."
- Prof. Zombie: passa dalla parte dei buoni perché il Regista "ha sbagliato una data storica".
- Ladro d'Asfalto, Drago Gonfiabile, Gelato Gigante: reclutati a suon di gag.

**Atto 2 — La Torre del Maxischermo.** Salita verticale sulla torre del Maxischermo Centrale: platforming anti-gravità, sezioni aeree col veicolo volante, muri da MEGABLAST. A metà torre, il Regista separa Kai e Zara per la prima volta in tutto il gioco: due percorsi paralleli a schermo condiviso, e il giocatore switcha per aprire la strada all'altro. È la prova finale del pilastro "il Duo è uno solo": *divisi non funzionano, insieme sono invincibili.*

**Atto 3 — Il Boss Finale: IL REGISTA (3 fasi).**

- *Fase 1 — "Il Copione":* il Regista scrive gli attacchi sullo schermo come didascalie ("KAI INCIAMPA", "ZARA CADE") e gli attacchi accadono davvero. Soluzione: Kai usa la **Laser Penna** per *riscrivere le didascalie* ("KAI SCHIVA TUTTO"), Zara urla per cancellarle.
- *Fase 2 — "La Lega Pentita":* il Regista evoca versioni ombra dei 6 boss. Ma i boss veri — ormai pentiti — irrompono uno a uno e neutralizzano le proprie ombre, gridando le frasi-firma dei giocatori. Momento da standing ovation pixelata.
- *Fase 3 — "Finale Serio":* il Regista assorbe il Maxischermo e diventa gigante, in bianco e nero, con musica drammatica. Dura esattamente 20 secondi: poi Zara gli fa lo **Shaka Stun**, Kai gli scrive sulla fronte "RIDICOLO", e la battaglia diventa un caos coloratissimo di tutti i poteri sbloccati nei sei capitoli, usati in sequenza rapida (QTE comico: ogni tasto premuto = un potere + una gag).

### 6.3 Il colpo di scena della 306

A battaglia persa, il Regista tenta la fuga in elicottero. Zara guarda Kai. Kai guarda la 306. La 306 *ronza*.

> **ZARA:** "Tesoro. Lo so che stai pensando quello che sto pensando io."
> **KAI:** "È una Peugeot 306. Non vola."
> **IL NONNO:** *(comparendo dal nulla, col Guanto Magico)* "Chi ha detto che non vola?"

**Sezione finale:** inseguimento aereo sulla Milano pixel con la **306 Volante** (Guanto Magico + Freno Antigravità + Burnout Potenziato). Il Regista viene sconfitto in volo, precipita sul Maxischermo e, nell'esplosione di pixel, il colore torna in tutta la città in un'onda arcobaleno che parte dalla 306.

Il Regista, sconfitto, ammette: "…ok. Il vostro finale era meglio." Diventa l'**NPG della Galleria** nel garage: commenta le splash page come un critico d'arte frustrato.

### 6.4 Doppio finale

**Finale A (standard):** festa in piazza con tutti i boss redenti. La mamma di Kai alza il bicchiere. Il nonno regala alla 306 un guanto magico di riserva ("Per la stagione 2"). Splash page finale: Kai e Zara che volano sopra Milano, la 306 parcheggiata sotto di loro. Testo: *"Fine dell'avventura… o forse solo l'inizio della prossima volta. (Continua…)"*

**Finale B (100% — tutte le merendine, tutte le figurine, tutte le gag viste):** dopo i titoli di coda, notte di Halloween a casa della mamma di Kai. Il campanello suona. Zara apre. Sul pianerottolo c'è il **Regista in costume da zucca**, imbarazzatissimo: "Mi hanno detto che qui ci sono le feste migliori." Zara lo trascina dentro. Kai sospira: "Di nuovo?" — e sorride. Testo: *"Stagione 2: Halloween Infernale. Preparatevi."*

---

## 7. Tabella di Progressione dei Poteri

| Cap. | Kai | Zara | Duo / 306 |
|---|---|---|---|
| 1 | Chiave Inglese | Tubo-Scudo, Shaka Stun | Chiamata Peugeot |
| 2 | Laser Penna | MEGABLAST | — |
| 3 | Penna-Forbici, Anti-Gravità | Urlo della Verità, Anti-Gravità | Skateboard |
| 4 | Scudo Maglietta | — | Pugno Duo |
| 5 | Veicolo Volante | Freno Antigravità | Guida libera 306 (Patente da Eroe) |
| 6 | Supervitamine | Gigantismo | Burnout della Peugeot Potenziato |
| **Finale** | Riscrittura Didascalie | Shaka Stun Potenziato | **306 Volante** |

---

## 8. Loop di Gioco, Gag e Collezionabili

**Loop:** Hub (garage) → viaggio in 306 al distretto → premessa comica → livello → boss → sezione auto → splash page → ritorno all'hub con un potere nuovo.

**Gag:** 2-3 slapstick scriptate per livello (cadute di Zara, inciampi di Kai, occhiali che scivolano) + banter dinamico in combattimento.

**Collezionabili:**

- **7 Merendine segrete** (una per livello): valuta del negozio + chiave del Capitolo Finale.
- **Figurine fumetto:** sbloccano outfit alternativi e artwork nella Galleria.
- **Gag dorate:** momenti comici opzionali nascosti nei livelli; trovarli tutti sblocca il Finale B.

---

## 9. Note Tecniche (indicative)

- Risoluzione interna 320x180, tile 16x16, 60 fps.
- Palette: rosso/blu per i protagonisti, toni caldi per le scene romantiche, saturi per le battaglie, **scala di grigi per il Finale (Atto 1-2)** con ritorno di colore progressivo.
- Salvataggio: sul divano di casa o alla 306.
- Controlli: movimento, attacco base, potere speciale, schivata, switch personaggio, mossa Duo, chiamata 306.

---

## 10. Prossimi Passi

1. Prototipo del Cap. 1 (movimento, switch, Robot Pizzaiolo).
2. Sistema dialoghi JSON con banter dinamico e frasi-firma.
3. Mappa hub e viaggio in 306 tra distretti.
4. Un potere nuovo per ogni milestone di sviluppo.
5. Pitch del Gran Finale come obiettivo di fine produzione.

*"Fine dell'avventura… o forse solo l'inizio. (Continua…)"*
