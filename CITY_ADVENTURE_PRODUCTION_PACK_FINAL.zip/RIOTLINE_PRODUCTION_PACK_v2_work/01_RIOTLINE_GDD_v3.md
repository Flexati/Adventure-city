# RIOTLINE — Game Design Document v3.0

## 1. High concept
**RIOTLINE** is a 2D illustrated urban action-adventure about Kai and Zara, a chaotic young duo who move through Rookside — a dense, peripheral, lived-in city of ring roads, apartment blocks, schools, repair shops, supermarkets, flyovers, parks, arcades and late-night storefronts — while increasingly impossible events begin behaving as if somebody is scripting their lives.

The hook is not only combat. **The city remembers what the player does.** Conversations, intervention style, who gets protected, who gets humiliated, who gets trusted and which shortcuts are taken can permanently open or close missions, ally states, traversal options, combat variants, social scenes and ending material.

The game should be pitchable in one line:
> Two inseparable heroes, one indestructible hatchback, and a city whose story changes when the player refuses to follow the script.

## 2. Brand pillars
1. **The Duo is one system.** Kai and Zara are mechanically different but narratively inseparable.
2. **Rookside reacts.** Choices leave visible and systemic scars or improvements in neighborhoods.
3. **The Vortex VX-3 is the third protagonist.** Hub, vehicle, escape tool, social space, upgrade platform, comedic icon.
4. **Comedy has gameplay consequences.** Gags are not decoration; many are attacks, traversal tools, distractions, or branch triggers.
5. **Every chapter creates a social memory.** NPCs remember outcomes and later scenes acknowledge them.
6. **No morality bar.** The game tracks styles, trust, relationships and consequences instead of labeling choices good/bad.
7. **Every 20–40 seconds should contain something clip-worthy.** Not forced memes: readable reactions, surprise reversals, stylish abilities, physical comedy, or quotable banter.

## 3. Visual direction
Modern 2D illustration with strong line economy, graphic shadows, expressive faces and animation poses readable at phone scale. Character silhouettes must be recognizable without facial detail. Effects use comic typography, hand-drawn impact shapes and controlled neon accents against grounded urban environments.

The city is contemporary and peripheral rather than futuristic: cracked asphalt, rail bridges, convenience shops, apartment courtyards, garages, schools, small malls, fenced courts, laundromats, underpasses, warehouses, bus stops, repair yards. Technology exists, but the world is not cyberpunk.

## 4. Core playable characters
### Kai — “Super Penna”
- Tall, slim, messy brown hair, glasses, blue-accent visual identity.
- Precise, reluctant, analytical, romantically awkward.
- Combat: ranged precision, improvised tool attacks, written projectiles, utility manipulation.
- Signature readability: glasses adjustment, narrow silhouette, blue written trails.

### Zara — “Luce Rossa”
- Long red hair, green eyes, red-accent visual identity.
- Impulsive, fearless, protective, theatrically competitive.
- Combat: close-range pressure, area control, scream waves, shield improvisation.
- Signature readability: planted stance, wide attacks, red shock rings.

### Duo System
Instant switch, contextual assists, shared Duo meter, rescue reactions, combo finishers and branch-specific Duo moves. Companion AI must never steal boss finishes unless scripted.

## 5. Vortex VX-3
A fictional white compact hatchback with a square, slightly stubborn silhouette. It is inexplicably reliable, occasionally seems to arrive before the heroes, and becomes visually personalized by player choices.

Functions:
- mobile checkpoint and save anchor;
- district travel and later free-drive traversal;
- cosmetic collection display;
- optional upgrade bench;
- chase and escape sequences;
- Duo attacks and late-game anti-gravity conversion;
- relationship scenes between missions.

## 6. Rookside — city structure
Rookside is a connected 2D city made of seven principal zones plus transitional streets.

1. **South Blocks** — homes, pizzeria, laundromat, basketball court, alley network.
2. **Civic School Belt** — school, old quarry tunnel, museum depot, parking structures.
3. **Switchyard Park** — skate park, railway edge, drainage channel, rooftop billboard route.
4. **Garden Estate** — Zara’s grandfather’s property, community hall, repair shed, residential lanes.
5. **Ringroad Training Grounds** — driving school, vehicle yard, flyover ramps, industrial fringe.
6. **Rookside Mall District** — supermarket, arcade, service corridors, parking roof, loading docks.
7. **Broadcast Core** — downtown edge dominated by the city screen/tower used by the Regista.

Traversal expands through story choices. Helping a district can unlock shortcuts, safehouses, NPC transport, alternate shop stock or branch missions; ignoring or exploiting it can open different opportunities instead.

## 7. Core loop
Explore district → encounter local problem → talk/investigate → make at least one consequential choice → action sequence → boss/set-piece → Vortex section → consequence scene → return to hub / roam city → new branch, ally, power variant or complication.

## 8. Choice architecture
Four hidden tendencies are tracked, none shown as morality:
- `duo_trust`: how often Kai and Zara support rather than override each other;
- `district_bond`: how much the player invests in ordinary people and local places;
- `improv_style`: preference for improvisation versus controlled plans;
- `script_awareness`: how aggressively the player investigates “out-of-script” anomalies.

Choices also set binary world flags and NPC relationship flags. Major consequences can include:
- mission availability;
- ally presence in later levels;
- boss rematch behavior;
- shortcuts or hazards;
- power variants;
- altered Vortex cosmetics/upgrades;
- changed dialogue and social scenes;
- different final-battle assists;
- ending epilogues.

No single playthrough exposes all content.

## 9. Combat
### Kai
- Wrench jab / launcher.
- Laser Pen: written bolts and utility words.
- Pen-Scissors: cable and shield cutting.
- Shirt Guard: timing-based parry gag.
- Supervitamins: temporary Duo support buff.
- Rewrite Caption: final-act reality manipulation.

### Zara
- Pipe Shield bash/parry.
- Shaka Stun.
- Megablast.
- Truth Scream.
- Anti-gravity brake.
- Gigantism burst.

### Duo
- instant switch shockwave;
- Pugno Duo;
- relationship-dependent finishers;
- Vortex call;
- upgraded Vortex burnout;
- anti-gravity Vortex finale.

## 10. Progression philosophy
Progression should give the player **new verbs**, not only larger numbers. A new power should alter exploration, dialogue resolution, combat and at least one old district when revisited.

Each chapter adds one core capability; branch choices add modifiers or alternate applications, not mandatory paywalled power.

## 11. Chapters overview
### Chapter 1 — “Pizza Protocol”
A polite delivery robot steals every pizza in South Blocks under instructions it cannot explain. The player chooses whether to publicly humiliate it, quietly disable its directive, or protect the pizzeria owner’s business first. This choice determines whether the robot becomes an ally, comic rival, or reluctant informant.

Boss: Robot Pizzaiolo. Unlocks base tools, Shaka Stun and Vortex Call.

### Chapter 2 — “Field Trip From Hell”
A school excursion intersects with a fossil tunnel, a corrupted quiz system and a Prof. Zombie obsessed with proving intellectual superiority. A recurring visual symbol appears in the environment for the first time: a broken storyboard frame.

Player choice determines whether students become recurring street informants, whether the professor later helps decode the Regista’s archive, and whether Kai or Zara leads the resolution.

Unlocks Laser Pen and Megablast.

### Chapter 3 — “Air Under Asphalt”
At Switchyard Park, a stolen board and a modified drone cause sections of the park to lose gravity. The player can side with neighborhood skaters, formalize the park with city authorities, or preserve its illegal culture.

The district physically changes after the chapter. Unlocks anti-gravity movement and new traversal.

### Chapter 4 — “Birthday Override”
Zara’s grandfather’s birthday is interrupted by an obsolete gift-distribution robot following a thirty-year-old instruction set. The grandfather reveals that some of his abandoned inventions have recently received external update packets.

The player decides how much to tell the family about the “script” pattern. This affects Duo trust and opens or closes a private workshop branch.

Unlocks Shirt Guard and Pugno Duo.

### Chapter 5 — “License to Break Routine”
The driving school becomes the center of an escalating vehicle chase when a helmet thief and a giant inflatable dragon turn a test into a citywide spectacle. The Vortex becomes freely drivable afterward.

Player decisions determine whether free driving is framed as civic trust, underground access, or controlled chaos, affecting later police/security behavior without creating a wanted-level clone.

Unlocks Anti-gravity Brake, airborne vehicle sequences and city free-drive.

### Chapter 6 — “The Mall Eats Back”
A mall/supermarket complex becomes a shifting combat maze. The giant gelato is not random: it is an unstable “finale prop” prematurely activated. The Regista’s authorship becomes undeniable.

The player must choose between saving trapped NPCs, chasing the source signal immediately, or preserving evidence. The choice changes the final chapter’s resources and who believes the duo.

Unlocks Gigantism, Supervitamins and upgraded Vortex burnout.

### Chapter 7 — “Off Script”
Rookside loses color and spontaneity as the Regista locks the city into a “perfect serious finale.” Past branch choices determine which districts resist, which allies arrive, which bosses defect, and which traversal routes remain available.

Boss Phase 1: The Script — on-screen captions become attacks; Kai rewrites and Zara erases them.
Boss Phase 2: Echo Cast — shadow versions of previous bosses appear; recruited allies can neutralize or complicate them.
Boss Phase 3: Perfect Ending — the Regista tries to force a single canonical ending. The player wins by using accumulated contradictory choices as mechanical ammunition.

Final chase: anti-gravity Vortex VX-3 versus the Regista’s escape craft over Rookside.

## 12. Endings
Rather than “good/bad,” endings are **epilogue compositions** assembled from branch outcomes.

Base ending always resolves the Regista conflict. Optional epilogues cover:
- Kai/Zara relationship tone;
- status of each district;
- fate of former bosses;
- Vortex identity/cosmetic state;
- grandfather workshop status;
- city attitude toward the duo;
- whether the Regista becomes critic, archivist, fugitive or reluctant collaborator.

A 100% “Golden Outtake” ending requires discovering all hidden gag scenes plus a high script-awareness route, but should not invalidate other endings.

## 13. Social/viral design targets
- Each boss must have one instantly readable visual gag.
- Each power needs a 1–2 second anticipation pose suitable for thumbnails/clips.
- Vortex has recurring arrival/burnout beats.
- Choice consequences should create “I got THIS version” comparison moments.
- Avoid meme references dependent on current trends; build original recurring bits.

## 14. Accessibility
- remappable controls;
- reduced camera shake;
- reduced flashes;
- subtitle size and speaker labels;
- color-independent combat telegraphs;
- dialogue auto-advance toggle;
- aim assistance and timing-window options;
- no monetization gate on accessibility features.

## 15. Content boundaries
Romance remains affectionate and non-sexual. Comedy may be chaotic but should avoid cruelty as the default joke. The game should feel irreverent, not cynical.
