# RIOTLINE — Monetization & Entitlements

## Principle
Monetization is an implementation layer, not a story designer. Purchases and ads may change convenience, cosmetics, ownership and optional reward cadence; they must not alter canonical story flags or lock accessibility.

## One-codebase architecture
Prepare the game for configurable distribution modes:

### Mode A — Free + Full Unlock
- free install;
- meaningful opening slice;
- optional rewarded ads;
- one non-consumable `full_game_unlock`;
- unlock removes progression gate and can disable interstitial placements globally.

### Mode B — Premium
- paid install;
- all story content unlocked;
- no mandatory ads;
- optional cosmetic/expansion IAP only.

### Mode C — Store-configured hybrid
Same binary behavior controlled by remote/store entitlement configuration; do not fork gameplay code unnecessarily.

## Entitlements
- `full_game_unlock`
- `remove_ads`
- `supporter_cosmetic_pack_01`
- future expansion flags separate from base story.

## Ad policy inside game design
Allowed placements:
- optional rewarded continue after non-story challenge failure;
- optional reward multiplier on post-mission resource screen;
- optional cosmetic reroll/reward where regulations/store policy permit;
- interstitial only at natural chapter/session boundaries and frequency capped.

Forbidden placements:
- during boss fight;
- during choice countdown;
- before/after emotional scene in a way that breaks continuity;
- required to obtain canonical clues;
- required to use accessibility features;
- deceptive buttons or fake close controls.

## Economy
Prefer cosmetics, optional convenience and supporter purchases over power sale. Story powers are earned through play.

## Telemetry events to prepare
`chapter_start`, `chapter_complete`, `choice_made`, `choice_consequence_seen`, `boss_attempt`, `boss_win`, `duo_switch`, `rewarded_offer_shown`, `rewarded_completed`, `purchase_started`, `purchase_completed`, `full_unlock_restored`, `session_end`.

Analytics must avoid storing dialogue free-text or unnecessary personal data.
