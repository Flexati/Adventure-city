# RIOTLINE — Art Bible

## Target identity
The art must feel authored for RIOTLINE, not generated from a generic “indie 2D game” prompt. The reference image in `assets/reference/visual_direction_reference.png` is a **directional reference**, not a final canonical sheet. Preserve its density, energy, graphic readability and urban-comic attitude while moving the production away from mandatory retro pixel art.

## Core look
- illustrated 2D, high-contrast silhouettes;
- grounded contemporary urban backgrounds;
- selective neon/accent lighting, not cyberpunk citywide;
- expressive smear frames and squash/stretch;
- thick-to-medium contour hierarchy;
- clean negative space around player characters;
- comic-impact shapes and onomatopoeia as VFX layers;
- animation-first design: no costume detail that collapses at gameplay scale.

## Character consistency locks
### Kai
Must always retain: messy brown hair mass, glasses, slim/tall proportions, blue accent family, precise hand posing, slightly guarded posture.

### Zara
Must always retain: long red hair mass, green-eye identity when visible, strong hips/shoulders stance, red accent family, broader action arcs.

### Vortex VX-3
White fictional hatchback; compact squared proportions; no real-manufacturer badge; front three-quarter silhouette must be instantly recognizable; one signature asymmetrical detail should survive every skin (recommended: offset blue/red tow-loop pair).

## Animation minimums
Playable characters each require:
- idle A/B;
- walk 8-direction or side-view equivalent depending implementation;
- run;
- start/stop;
- jump ascent/apex/fall/land;
- dodge;
- light combo;
- heavy/special anticipation;
- hit reactions x3;
- knockdown/recover;
- interact;
- talk/listen;
- Duo assist;
- victory;
- chapter-specific power animations.

## Social-ready frame rule
Every major action needs at least one “poster frame”: a readable extreme pose that can be isolated for thumbnails, store art and short-form video. This frame may be a keyframe in the animation but cannot harm gameplay timing.

## Environment families
1. South Blocks — warm storefronts, concrete, graffiti layers, parked scooters/bikes, apartment balconies.
2. Civic School Belt — institutional green/cream surfaces, fencing, fluorescent interiors, quarry stone.
3. Switchyard Park — steel, faded paint, rails, open sky strips, drainage water.
4. Garden Estate — domestic warm palette, improvised inventions, community decor.
5. Ringroad — asphalt, concrete barriers, signage, service buildings, sodium/LED mix.
6. Mall District — glossy commercial color against service-corridor grime.
7. Broadcast Core — severe geometry that becomes desaturated during finale.

## VFX language
Kai effects: linear, written, geometric, blue-white.
Zara effects: radial, pressure-wave, red-orange.
Duo effects: overlap creates magenta/white interference motif.
Regista effects: monochrome captions, registration marks, crop lines, frame guides.

## Asset generation rule
Never generate final production sprites as one giant mixed collage. Use one character/asset family per generation pass, lock the master turnaround, then derive animation sheets from that master. Reject any sheet where face, proportions, costume, weapon or silhouette drift between frames.
