<!-- 212/310 -->
# character.bran_kess.01 — Bran Kess · v01

Stato: **PROMPT_READY** · nessuna immagine generata · CONCEPT_ONLY: nessuna scena giocabile, si produce lo stesso (autorizzazione dell’autore) · `COMMERCIAL_RELEASE = BLOCKED`

Produzione: GPT Immagine, poi controllo del team

**Allegati da caricare in GPT** (cartella `riferimenti/`): `ref_npc_stile.png`

**Consegna**: ramo `delivery/gpt-preproduzione-310-20261029`, cartella `deliveries/gpt-preproduzione-310-20261029/character/character_bran_kess/`, file: `v01.png`, `v01_ritratti.png`

Master atteso nel registro dopo i controlli: `assets/preproduction/v10.2/variants/character/character_bran_kess/v01.png`

```
Sei l'illustratore di CHRONOS Adventure: Nox & Lulù. Disegna la tavola personaggio di Bran Kess, variante 01.

1. IDENTITÀ E COLLEGAMENTO NARRATIVO
Bran Kess: fabbro di Moon Refuge che ricostruisce tecnologia Elyon senza sistemi di controllo. Personalità visiva: burbero e generoso. Genere: maschile (proposta).
Variante 01: Fabbro: grembiule con residui di fucina.


2. SOGGETTO, MATERIALI E COLORI
- Aspetto: fabbro robusto, braccia larghe, barba corta, grembiule di cuoio con bruciature e residui di fucina.
- Materiali con usura credibile: tessuti con pieghe e cuciture, cuoio graffiato, metallo con riflessi netti.
- Palette (hex): #5A3E2A, #C86A2A, #3A3A40, #E8C8A0.
- Gesto e attività della variante: Fabbro: grembiule con residui di fucina. Un oggetto di lavoro in mano o vicino quando la variante lo nomina.

3. STILE
Pixel art HD dettagliata come gli sprite canonici del gioco (riferimenti ref_protagonisti.png e ref_npc_stile.png): proporzioni realistiche leggermente stilizzate (circa 6,5 teste), contorno scuro di 1 pixel, ombreggiatura a gradini con 3-4 toni per materiale, riflessi netti su metallo e tessuti lucidi, luce dall'alto a sinistra. Volti leggibili anche a 110 px di altezza sullo schermo. Mai tinta unita: pieghe, cuciture, usura, accessori.

4. ANGOLAZIONE, PROSPETTIVA, LUCE, PROPORZIONI
- Figure intere in piedi, viste dalla camera del gioco (leggermente dall'alto), piedi tutti sulla stessa linea di base.
- Altezza della figura circa 300 px nell'immagine; stessa scala in tutte le pose.
- Luce dall'alto a sinistra, ombra propria a gradini, nessuna ombra portata a terra.

5. VISTE, POSE E VARIANTI DA PRODURRE
A. v01.png: model sheet 1536×1024 con sei figure in fila: fronte, schiena, lato destro, 3/4 di schiena, posa idle, gesto caratteristico della variante.
B. v01_ritratti.png: tre ritratti busto 512×512 affiancati (1536×512) come i ritratti del gioco (ref_protagonisti.png, portraits.png): emozioni neutra, tesa, serena; sfondo pittorico scuro della sua città, nessun testo.
Questa è la variante master (01): fissa volto, capelli, corporatura e abiti.

6. COERENZA DELLA FAMIGLIA
- Lo stesso volto, gli stessi capelli e gli stessi colori in tutte le figure e nei tre ritratti.
- Le tre varianti dello stesso personaggio sono la stessa persona: cambia la situazione, non l'identità.
- Stile e scala coerenti con gli NPC del gioco (ref_npc_stile.png).

7. SFONDO, FORMATO E RISOLUZIONE
- A: PNG 1536×1024. Sfondo verde puro #00FF00 piatto in tutta l'immagine (il team lo toglie). Nessuna ombra a terra fuori dal soggetto, nessun alone verde sul soggetto, nessun colore del soggetto vicino al verde: le parti verdi richieste vanno in verde oliva scuro, smeraldo scuro o menta chiara #9FF7B8. Almeno 40 px di verde su ogni lato.
- B: PNG 1536×512, sfondo pittorico scuro.

8. RESTRIZIONI
- non cambiare volto, età, corporatura o colori fra le figure
- nessuna caricatura, nessuno stereotipo etnico o di disabilità
- nessun tratto aggressivo se la variante non lo chiede
- nessun marchio, logo o testo leggibile reale; scritte e simboli solo inventati e illeggibili
- nessun personaggio, opera o stile riconoscibile di altre proprietà intellettuali
- nessuna persona reale riconoscibile
- non inventare valori di gioco: niente numeri di danno, hitbox, raggi o tempi scritti nell'immagine
- niente tinta unita piatta, niente sfumature morbide da pittura digitale, niente stile 3D o fotografico
```

---
