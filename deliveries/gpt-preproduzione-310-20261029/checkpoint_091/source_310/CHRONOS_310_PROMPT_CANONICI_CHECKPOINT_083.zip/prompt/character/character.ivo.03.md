<!-- 235/310 -->
# character.ivo.03 — Ivo Contrappeso · v03

Stato: **PROMPT_READY** · nessuna immagine generata · CONCEPT_ONLY: nessuna scena giocabile, si produce lo stesso (autorizzazione dell’autore) · `COMMERCIAL_RELEASE = BLOCKED`

Produzione: GPT Immagine, poi controllo del team

**Allegati da caricare in GPT** (cartella `riferimenti/`): `ref_npc_stile.png`

**Consegna**: ramo `delivery/gpt-preproduzione-310-20261029`, cartella `deliveries/gpt-preproduzione-310-20261029/character/character_ivo/`, file: `v03.png`, `v03_ritratti.png`

Master atteso nel registro dopo i controlli: `assets/preproduction/v10.2/variants/character/character_ivo/v03.png`

```
Sei l'illustratore di CHRONOS Adventure: Nox & Lulù. Disegna la tavola personaggio di Ivo Contrappeso, variante 03.

1. IDENTITÀ E COLLEGAMENTO NARRATIVO
Ivo Contrappeso: proposta NON adottata (D03): solo studio d’archivio. Personalità visiva: —. Genere: maschile (proposta).
Variante 03: Non creare NPC runtime senza nuova decisione.
ATTENZIONE: proposta NON adottata (decisione D03). Studio d’archivio, non entra nel gioco.

2. SOGGETTO, MATERIALI E COLORI
- Aspetto: ipotesi: operaio dei contrappesi di Aurelia Span, imbracatura, guanti, corda sulla spalla.
- Materiali con usura credibile: tessuti con pieghe e cuciture, cuoio graffiato, metallo con riflessi netti.
- Palette (hex): #3A6AB0, #C86A4A, #E8E0CC, #5A5F68.
- Gesto e attività della variante: Non creare NPC runtime senza nuova decisione. Un oggetto di lavoro in mano o vicino quando la variante lo nomina.

3. STILE
Pixel art HD dettagliata come gli sprite canonici del gioco (riferimenti ref_protagonisti.png e ref_npc_stile.png): proporzioni realistiche leggermente stilizzate (circa 6,5 teste), contorno scuro di 1 pixel, ombreggiatura a gradini con 3-4 toni per materiale, riflessi netti su metallo e tessuti lucidi, luce dall'alto a sinistra. Volti leggibili anche a 110 px di altezza sullo schermo. Mai tinta unita: pieghe, cuciture, usura, accessori.

4. ANGOLAZIONE, PROSPETTIVA, LUCE, PROPORZIONI
- Figure intere in piedi, viste dalla camera del gioco (leggermente dall'alto), piedi tutti sulla stessa linea di base.
- Altezza della figura circa 300 px nell'immagine; stessa scala in tutte le pose.
- Luce dall'alto a sinistra, ombra propria a gradini, nessuna ombra portata a terra.

5. VISTE, POSE E VARIANTI DA PRODURRE
A. v03.png: model sheet 1536×1024 con sei figure in fila: fronte, schiena, lato destro, 3/4 di schiena, posa idle, gesto caratteristico della variante.
B. v03_ritratti.png: tre ritratti busto 512×512 affiancati (1536×512) come i ritratti del gioco (ref_protagonisti.png, portraits.png): emozioni neutra, tesa, serena; sfondo pittorico scuro della sua città, nessun testo.
MODIFICA la tua immagine v01.png dello stesso personaggio (allegala): stesso volto, stessi capelli, stessa corporatura; cambiano solo gli elementi della variante «Non creare NPC runtime senza nuova decis».

6. COERENZA DELLA FAMIGLIA
- Lo stesso volto, gli stessi capelli e gli stessi colori in tutte le figure e nei tre ritratti.
- Le tre varianti dello stesso personaggio sono la stessa persona: cambia la situazione, non l'identità.
- Stile e scala coerenti con gli NPC del gioco (ref_npc_stile.png).

7. SFONDO, FORMATO E RISOLUZIONE
- A: PNG 1536×1024. Sfondo verde puro #00FF00 piatto in tutta l'immagine (il team lo toglie). Nessuna ombra a terra fuori dal soggetto, nessun alone verde sul soggetto, nessun colore del soggetto vicino al verde: le parti verdi richieste vanno in verde oliva scuro, smeraldo scuro o menta chiara #9FF7B8. Almeno 40 px di verde su ogni lato.
- B: PNG 1536×512, sfondo pittorico scuro.

8. RESTRIZIONI
- non cambiare volto, età, corporatura o colori fra le figure
- nessuna caricatura, nessuno stereotipo etnico o di disabilità
- nessun tratto aggressivo se la variante non lo chiede
- nessun marchio, logo o testo leggibile reale; scritte e simboli solo inventati e illeggibili
- nessun personaggio, opera o stile riconoscibile di altre proprietà intellettuali
- nessuna persona reale riconoscibile
- non inventare valori di gioco: niente numeri di danno, hitbox, raggi o tempi scritti nell'immagine
- niente tinta unita piatta, niente sfumature morbide da pittura digitale, niente stile 3D o fotografico
```

---
