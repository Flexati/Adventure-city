<!-- 11/310 -->
# region.solkara.03 — Solkara · v03

Stato: **PROMPT_READY** · nessuna immagine generata · contenuto già nel gioco · `COMMERCIAL_RELEASE = BLOCKED`

Produzione: GPT Immagine, poi controllo del team

**Allegati da caricare in GPT** (cartella `riferimenti/`): `ref_stile_mappe.png`

**Consegna**: ramo `delivery/gpt-preproduzione-310-20261029`, cartella `deliveries/gpt-preproduzione-310-20261029/region/region_solkara/`, file: `v03.png`, `v03_notte.png`, `v03_evento.png`, `v03_props.png`

Master atteso nel registro dopo i controlli: `assets/preproduction/v10.2/variants/region/region_solkara/v03.png`

```
Sei l'illustratore di CHRONOS Adventure: Nox & Lulù, avventura d'azione per Android. Disegna il quartiere «Officine itineranti» della regione Solkara.

1. IDENTITÀ E COLLEGAMENTO NARRATIVO
Città-convoglio nel deserto senza sistema centrale: l'ombra dei telai viaggia con le persone. Le gare di Solkara corrono fra i convogli.
Questo quartiere: Officine itineranti: riparatori, piccoli mercati, taniche e cricchi
Gli altri quartieri della stessa regione (Piazza del convoglio, Via delle ruote, Finestra del passo) condividono materiali e palette ma hanno una funzione diversa: questo deve essere riconoscibile al primo sguardo.

2. SOGGETTO, MATERIALI E COLORI
- Architettura: piattaforme su ruote gigantesche con case di tela e legno, telai di sollevamento, cisterne d'acqua, vele parasole a strisce, scale mobili fra un vagone e l'altro, banderuole.
- Suolo e strade: sabbia ocra con increspature del vento, solchi delle ruote, impronte, tavole posate come passerelle, teli stesi.
- Attività commerciali visibili: punti d'acqua, officine itineranti con cricchi e taniche, mercato di stoffe e spezie (senza stereotipi), tessitori di vele.
- Abitanti (almeno 14, piccoli come nel gioco, ognuno impegnato in un'attività riconoscibile: lavorare, trasportare, vendere, riparare, parlare, giocare): abitanti con abiti protettivi chiari scoloriti dal sole, foulard e occhiali da sabbia, meccanici con guanti, bambini sulle scale.
- Oggetti ambientali da distribuire nella scena: tanica arancio, cricco da camion, cisterna d'acqua con rubinetto, vela parasole, ruota di ricambio, banderuola, cassa di stoffe, lanterna da telaio.
- Palette di riferimento (hex): #D8B070, #B88E52, #C84A3A, #E8E0CC, #3A6AB0, #5A4630, #3A8AB0, #FFCF7A. Ogni materiale con almeno tre toni e micro-texture.

3. STILE
Pixel art HD ad alta densità di dettaglio, come le mappe canoniche del gioco (riferimento ref_stile_mappe.png: city.png, port.png, clinic.png, fracture.png, strade di Ash Docks). Vista dall'alto 3/4 con camera alta, pixel netti e visibili ma piccoli (scala HD, non pixel giganti), contorni scuri sottili, ombreggiatura a gradini, luce principale dall'alto a sinistra. Ogni superficie è lavorata: tetti con impianti, condizionatori, parabole, tubi, casse, cavi, insegne inventate senza testo leggibile, crepe, macchie, pozzanghere con riflessi. Colori saturi e vivi, mai tinta unita piatta: ogni materiale ha almeno tre toni e micro-texture. La strada percorribile resta sempre leggibile rispetto agli edifici.

4. INQUADRATURA, PROSPETTIVA, LUCE E COMPOSIZIONE
- Camera alta in vista dall'alto 3/4 come le mappe del gioco: tetti visibili, facciate anteriori in scorcio.
- Composizione esplorabile: una strada o passaggio principale che attraversa l'immagine dal basso all'alto, almeno due uscite laterali, piazzette e incroci dove il giocatore può fermarsi; nessun vicolo chiuso ambiguo.
- Densità alta ai lati, percorso centrale libero e leggibile con il joystick.
- Luce del giorno: sole bianco e caldo, ombre corte e nette dei telai, aria tremolante.

5. IMMAGINI DA PRODURRE, IN QUESTO ORDINE
A. v03.png: il quartiere di giorno, 1536×1024, a tutto campo.
B. v03_notte.png: MODIFICA l'immagine A, non rigenerarla: stessa geometria, stessi edifici e stesse persone nelle stesse posizioni. Cambiano solo la luce e le finestre. Notte: lanterne calde appese ai telai, falò in bracieri chiusi, cielo indaco.
C. v03_evento.png: MODIFICA l'immagine A con l'evento atmosferico: tempesta di sabbia: velo ocra, telai coperti, visibilità ridotta ma percorso sempre leggibile. Strade e uscite restano leggibili.
D. v03_props.png: foglio degli oggetti isolati, 1536×1024 su verde puro #00FF00, griglia 4×3, un oggetto per cella, stessi oggetti e stesso stile della scena: tanica arancio, cricco da camion, cisterna d'acqua con rubinetto, vela parasole, ruota di ricambio, banderuola, cassa di stoffe, lanterna da telaio.

6. COERENZA DELLA FAMIGLIA
- A, B e C sono la stessa immagine: confrontabili pixel per pixel nella geometria.
- Stessa palette e stessi materiali in tutti e quattro i quartieri di Solkara; scala di persone ed edifici uguale alle mappe del gioco (ref_stile_mappe.png).
- Gli oggetti del foglio D sono identici a quelli disegnati nella scena.

7. SFONDO, FORMATO E RISOLUZIONE
- A, B, C: PNG 1536×1024, immagine piena senza bordi, senza cornici e senza didascalie.
- D: PNG 1536×1024. Sfondo verde puro #00FF00 piatto in tutta l'immagine (il team lo toglie). Nessuna ombra a terra fuori dal soggetto, nessun alone verde sul soggetto, nessun colore del soggetto vicino al verde: le parti verdi richieste vanno in verde oliva scuro, smeraldo scuro o menta chiara #9FF7B8. Almeno 40 px di verde su ogni lato.

8. RESTRIZIONI
- non cambiare la geometria fra A, B e C
- nessuna scena generica neon intercambiabile: questa città ha la sua architettura
- nessuna arma puntata contro civili, nessun gore
- nessun elemento che sembri un pulsante o un indicatore di gioco
- nessun marchio, logo o testo leggibile reale; scritte e simboli solo inventati e illeggibili
- nessun personaggio, opera o stile riconoscibile di altre proprietà intellettuali
- nessuna persona reale riconoscibile
- non inventare valori di gioco: niente numeri di danno, hitbox, raggi o tempi scritti nell'immagine
- niente tinta unita piatta, niente sfumature morbide da pittura digitale, niente stile 3D o fotografico
```

---
