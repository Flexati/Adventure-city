<!-- 209/310 -->
# boss.volkov.02 — Volkov · v02

Stato: **PROMPT_READY** · nessuna immagine generata · CONCEPT_ONLY: nessuna scena giocabile, si produce lo stesso (autorizzazione dell’autore) · `COMMERCIAL_RELEASE = BLOCKED`

Produzione: GPT Immagine, poi controllo del team

**Allegati da caricare in GPT** (cartella `riferimenti/`): `ref_boss.png`

**Consegna**: ramo `delivery/gpt-preproduzione-310-20261029`, cartella `deliveries/gpt-preproduzione-310-20261029/boss/boss_volkov/`, file: `v02.png`, `v02_vfx.png`

Master atteso nel registro dopo i controlli: `assets/preproduction/v10.2/variants/boss/boss_volkov/v02.png`

```
Sei l'illustratore di CHRONOS Adventure: Nox & Lulù. Disegna la tavola 2 di 4 del boss Volkov: «Procedura».

1. IDENTITÀ E COLLEGAMENTO NARRATIVO
amministratore medico in uniforme clinica fredda, vincoli di recupero identificabili; la cura diventa controllo. Non associare disabilità o mutazione a colpa morale.
Momento di questa tavola: Procedura: segnali d'intervento ordinati e avvisi su pavimento separati da persone.
Le quattro tavole sono quattro momenti di produzione, NON quattro fasi di gioco.

2. SOGGETTO, MATERIALI E COLORI
- Corpo, materiali e dettagli unici, riconoscibili in silhouette.
- Palette (hex): #E8EEF2, #7AA8C8, #2A3A4A, #FF5A4A.
- Arena: Distretto Clinico, sala procedure, con zone sicure leggibili e uscite chiare.
- Attacco o stato del momento descritto, con l'avviso (telegraph) disegnato come effetto separato e chiaramente distinto dal colpo.

3. STILE
Pixel art HD dettagliata come gli sprite nemici canonici (ref_nemici.png: gang, infetti, custodi, alieni) e i boss (ref_boss.png): contorno scuro, ombre a gradini, materiali vissuti, luci emissive solo dove servono a leggere l'attacco. Silhouette riconoscibile in nero pieno a 110 px. Le arene seguono lo stile delle mappe (ref_stile_mappe.png).

4. ANGOLAZIONE, PROSPETTIVA, LUCE, PROPORZIONI
Camera del gioco dall'alto 3/4. Nella scena compare una sagoma di Nox alta come nel gioco, solo come confronto di scala: è una silhouette scura, NON va ridisegnato. Luce dell'arena coerente con la regione.

5. IMMAGINI DA PRODURRE
A. v02.png: scena 1536×1024 del momento: boss nell'arena, tre pose chiave del momento (anticipo, azione, recupero) in sovrapposizione leggera o in tre riquadri.
B. v02_vfx.png: effetti separati 1536×512 su verde: avviso, attacco, impatto, ritorno a riposo.

Allega la tua v01.png e v01_sprite.png dello stesso boss: stesso corpo, stessi colori, stessa arena.

6. COERENZA DELLA FAMIGLIA
Stesso boss, stessi colori e stessa arena nelle quattro tavole; gli effetti hanno sempre lo stesso colore d'avviso.

7. SFONDO, FORMATO E RISOLUZIONE
- A: PNG 1536×1024 a tutto campo.
- B: PNG. Sfondo verde puro #00FF00 piatto in tutta l'immagine (il team lo toglie). Nessuna ombra a terra fuori dal soggetto, nessun alone verde sul soggetto, nessun colore del soggetto vicino al verde: le parti verdi richieste vanno in verde oliva scuro, smeraldo scuro o menta chiara #9FF7B8. Almeno 40 px di verde su ogni lato.

8. RESTRIZIONI
- Valori di gioco: Nessun valore di gioco esiste: durata dell'avviso, hitbox, danno e area restano null; la tavola non li suggerisce con misure.
- nessun civile usato come arma o bersaglio
- nessuna demonizzazione di persone, malattia o disabilità
- il disegno non deve poter causare una falsa lettura del pericolo
- nessun marchio, logo o testo leggibile reale; scritte e simboli solo inventati e illeggibili
- nessun personaggio, opera o stile riconoscibile di altre proprietà intellettuali
- nessuna persona reale riconoscibile
- non inventare valori di gioco: niente numeri di danno, hitbox, raggi o tempi scritti nell'immagine
- niente tinta unita piatta, niente sfumature morbide da pittura digitale, niente stile 3D o fotografico

Brief audio per il team (non va disegnato): bip clinici, porte pneumatiche; anticipo, attacco e recupero hanno suoni distinti.
```

---
