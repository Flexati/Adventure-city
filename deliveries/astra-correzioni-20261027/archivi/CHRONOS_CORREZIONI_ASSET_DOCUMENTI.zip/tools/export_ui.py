from pathlib import Path
from PIL import Image
import numpy as np, json, shutil
R=Path(__file__).resolve().parents[1];G=Path('/workspace/generated_images');O=R/'assets'
def load(name,file):
 return Image.open(R/'masters'/f'{name}.png').convert('RGBA')
def crop_alpha(im):
 b=im.getchannel('A').point(lambda v:255 if v>20 else 0).getbbox();return im.crop(b)
def pack(crops,size,pad):
 scale=min(min((size[0]-2*pad)/im.width,(size[1]-2*pad)/im.height) for im in crops)
 result=[]
 for im in crops:
  im=im.resize((round(im.width*scale),round(im.height*scale)),Image.Resampling.NEAREST);o=Image.new('RGBA',size);o.alpha_composite(im,((size[0]-im.width)//2,(size[1]-im.height)//2));result.append(o)
 return result
im=load('icons','exec-6510e977-95d3-4907-978e-27414ce8b76e.png');cs=[crop_alpha(im.crop((round(i*im.width/3),0,round((i+1)*im.width/3),im.height))) for i in range(3)]
icons=pack(cs,(128,128),4)
preview=Image.new('RGB',(3*192,384),(36,36,36))
for i,(state,icon) in enumerate(zip(['normale','selezionata','non_disponibile'],icons)):
 icon.save(O/f'ICON_h17_{state}.png');small=icon.resize((48,48),Image.Resampling.LANCZOS);preview.paste(small.resize((192,192),Image.Resampling.NEAREST),(i*192,0),small.resize((192,192),Image.Resampling.NEAREST));gray=small.convert('LA').convert('RGBA').resize((192,192),Image.Resampling.NEAREST);preview.paste(gray,(i*192,192),gray)
preview.save(R/'reports/icons_48px_preview.png')
im=load('pylons','exec-6bc88901-37c0-4ce5-931b-0c16e270eb20.png');cs=[crop_alpha(im.crop((i*im.width//2,0,(i+1)*im.width//2,im.height))) for i in range(2)]
for state,img in zip(['attivo','superato'],pack(cs,(128,256),12)):img.save(O/f'RACE_ashdocks_cp_pylon_{state}.png')
im=load('tapes','exec-459bf59e-a53e-40e3-9ca7-b9ad7365b1c6.png')
for i,state in enumerate(['attivo','superato']):
 cell=crop_alpha(im.crop((0,i*im.height//2,im.width,(i+1)*im.height//2)))
 start,width=(190,320) if i==0 else (185,200)
 tile=cell.crop((start,0,start+width,cell.height)).resize((64,28 if i==0 else 24),Image.Resampling.NEAREST)
 a=np.array(tile);edge=np.rint((a[:,0].astype(float)+a[:,-1])/2).astype('uint8')
 for x in range(4):
  f=(4-x)/4;a[:,x]=np.rint(a[:,x]*(1-f)+edge*f);a[:,-1-x]=np.rint(a[:,-1-x]*(1-f)+edge*f)
 a[:,-1]=a[:,0];out=Image.new('RGBA',(64,32));out.alpha_composite(Image.fromarray(a),(0,(32-len(a))//2));out.save(O/f'RACE_ashdocks_cp_tape_{state}.png')
(R/'reports/UI.json').write_text(json.dumps({'icons':{'size':[128,128],'visible_cartridge_windows':4,'preview':'icons_48px_preview.png','human_approval':False},'pylons':{'size':[128,256],'count':2,'view':'overhead'},'tapes':{'size':[64,32],'first_last_columns_identical':True,'state_shape':'active tabs, passed holes'}},indent=2))
