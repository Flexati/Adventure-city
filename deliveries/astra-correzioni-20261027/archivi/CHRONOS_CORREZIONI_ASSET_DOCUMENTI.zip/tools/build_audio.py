from pathlib import Path
import numpy as np,json,subprocess,tempfile
from scipy.io import wavfile
R=Path(__file__).resolve().parents[1];S=48000
report={}
for name,d in [('race_count_beep',.22),('race_go',.85)]:
 t=np.arange(round(S*d))/S
 if name=='race_count_beep':
  x=(np.cos(2*np.pi*880*t)+.12*np.cos(2*np.pi*1760*t))*np.exp(-t*18)
 else:
  x=sum(np.cos(2*np.pi*f*t)*g for f,g in [(880,.5),(1100,.3),(1320,.3)])*np.exp(-t*6)
 x*=np.minimum(1,.1+t/.0015)
 x[-480:]*=np.linspace(1,0,480)
 x=x/np.max(np.abs(x))*10**(-3/20)
 with tempfile.TemporaryDirectory() as tmp:
  p=Path(tmp)/'s.wav';wavfile.write(p,S,x.astype('float32'))
  for ext,codec in [('flac',['-c:a','flac','-sample_fmt','s32']),('ogg',['-c:a','libvorbis','-q:a','7'])]:
   out=R/'assets'/f'{name}.{ext}'
   subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),*codec,str(out)],check=True)
   data=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(out),'-f','f32le','-']),dtype='<f4')
   peak=float(20*np.log10(np.abs(data).max()));onset=int(np.flatnonzero(np.abs(data)>1e-4)[0])
   assert peak<=-1 and onset<=1 and len(data)/S <= (.3 if name=='race_count_beep' else 1.5)
   report[out.name]={'rate':S,'duration':len(data)/S,'sample_peak_dbfs':peak,'onset_sample':onset,'human_listening':False}
(R/'reports/audio.json').write_text(json.dumps(report,indent=2))
print(report)
