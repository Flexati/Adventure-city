from pathlib import Path
from PIL import Image
from scipy import ndimage as nd
import numpy as np,json,shutil
R=Path(__file__).resolve().parents[1];src=R/'masters/G11_source.png'
a=np.array(Image.open(src).convert('RGBA'));alpha=a[:,:,3]
lab,n=nd.label(alpha>64,np.ones((3,3)));sizes=np.bincount(lab.ravel());ids=[i for i in range(1,n+1) if sizes[i]>3000]
assert len(ids)==32
owner=np.zeros_like(lab); info={}
for i in ids:
 ys,xs=np.where(lab==i);r=int(ys.mean()/(a.shape[0]/8));c=int(xs.mean()/(a.shape[1]/4));k=r*4+c+1
 assert k not in info
 owner[lab==i]=k;info[k]={'row':r,'col':c,'source_base':int(ys.max())}
# Assign detached nearby smoke and antialias pixels to the nearest whole pose, not nominal cell.
dist,indices=nd.distance_transform_edt(owner==0,return_indices=True)
nearest=owner[tuple(indices)];layers=[]
for k,d in sorted(info.items()):
 mask=(nearest==k)&(alpha>6)&(dist<14)
 ys,xs=np.where(mask);box=(int(xs.min()),int(ys.min()),int(xs.max()+1),int(ys.max()+1))
 rgba=np.where(mask[:,:,None],a,0).astype('uint8');im=Image.fromarray(rgba).crop(box)
 base=d['source_base']-box[1]
 layers.append((im,base,d,box))
scale=min(min(736/im.width,477/max(base,1),17/max(im.height-1-base,1)) for im,base,_,_ in layers)
out=Image.new('RGBA',(3072,4096));report=[]
for im,base,d,box in layers:
 w=max(1,round(im.width*scale));h=max(1,round(im.height*scale));im=im.resize((w,h),Image.Resampling.NEAREST)
 # Measure the same largest opaque body after scaling to anchor it exactly at 493.
 ar=np.array(im);labels,n=nd.label(ar[:,:,3]>64,np.ones((3,3)));sz=np.bincount(labels.ravel());sz[0]=0;ys,xs=np.where(labels==sz.argmax());b=int(ys.max())
 x=(768-w)//2;y=493-b
 assert x>=12 and y>=12 and y+h<=512 and x+w<=756,(d,x,y,w,h)
 out.alpha_composite(im,(d['col']*768+x,d['row']*512+y))
 report.append({**d,'source_bbox':box,'scale':scale,'body_base':y+b,'content_top':y,'content_bottom':y+h-1,'content_left':x,'content_right':x+w-1,'clipped_pixels':0})
out.save(R/'assets/BOSS_anchor_sheet.png')
assert all(d['body_base']==493 for d in report)
(R/'reports/G11.json').write_text(json.dumps({'source':str(src),'grid':[4,8],'cell':[768,512],'global_scale':scale,'method':'whole-component isolation then uniform nearest-neighbor scaling; no smoke fade or cell-boundary crop','cells':report},indent=2))
print('32 cells, common scale',scale,'base=493; no clipping')
