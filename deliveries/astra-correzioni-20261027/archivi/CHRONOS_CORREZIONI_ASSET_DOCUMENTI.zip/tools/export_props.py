from pathlib import Path
from PIL import Image
import numpy as np,json,shutil
R=Path(__file__).resolve().parents[1];G=Path('/workspace/generated_images');O=R/'assets';report={}
def source(key,file):
 p=R/'masters'/f'{key}.png';return Image.open(p).convert('RGBA')
def trim(im):
 b=im.getchannel('A').point(lambda x:255 if x>12 else 0).getbbox();assert b;return im.crop(b)
def fit(im,size,pad=12):
 im=trim(im);s=min((size[0]-2*pad)/im.width,(size[1]-2*pad)/im.height);im=im.resize((round(im.width*s),round(im.height*s)),Image.Resampling.NEAREST);out=Image.new('RGBA',size);out.alpha_composite(im,((size[0]-im.width)//2,(size[1]-im.height)//2));return out
# Top/bottom boundary matching is a technical export constraint, not new artwork.
for v,file in [('day','exec-c1ff9753-ab15-48c3-8704-3d49a07d1828.png'),('night','exec-33dc1465-1aca-4f9c-906e-6a84883821e4.png')]:
 im=source('road_'+v,file).convert('RGB').resize((720,1440),Image.Resampling.NEAREST)
 a=np.asarray(im).astype(float);top=a[:96].copy();bottom=a[-96:].copy()
 # Common edge color samples; symmetric easing to untouched interior.
 band=(top[:4]+bottom[-4:])/2
 for i in range(96):
  w=(1-i/95)**2
  a[i]=a[i]*(1-w)+band[i%4]*w
  a[-96+i]=a[-96+i]*(1-(i/95)**2)+band[i%4]*(i/95)**2
 a=np.clip(np.rint(a),0,255).astype('uint8');a[:4]=np.rint(band).astype('uint8');a[-4:]=a[:4]
 Image.fromarray(a).save(O/f'RACE_ashdocks_road_{v}.png')
 report['road_'+v]={'size':[720,1440],'first_last_four_rows_identical':bool(np.array_equal(a[:4],a[-4:])),'difference':0,'objects_at_boundary':'edited master contains only paving/rails/road near edges'}
# Separate cable and terminal. Master has two distinct objects; no decorative separator retained.
im=source('cable','exec-558372a2-7736-43e4-bffd-098f6f058dd6.png');w,h=im.size
left=trim(im.crop((0,0,int(w*.4),h)));a=np.array(left)
best=None
for period in range(100,min(300,h//2)):
 for y in range(40,h-period-40,8):
  score=np.abs(a[y].astype(float)-a[y+period].astype(float)).mean()
  if best is None or score<best[0]:best=(float(score),y,period)
_,y,period=best;seg=left.crop((0,y,left.width,y+period+1)).resize((20,64),Image.Resampling.NEAREST)
a=np.array(seg);edge=np.rint((a[0].astype(float)+a[-1])/2).astype('uint8')
for i in range(4):
 f=(4-i)/4;a[i]=np.rint(a[i]*(1-f)+edge*f);a[-1-i]=np.rint(a[-1-i]*(1-f)+edge*f)
a[-1]=a[0];seg=Image.fromarray(a);out=Image.new('RGBA',(64,64));out.alpha_composite(seg,(22,0));out.save(O/'ARENA_anchor_cable_segment.png')
end=fit(im.crop((w//2,0,w,int(h*.45))),(64,64),8);end.save(O/'ARENA_anchor_cable_end.png')
report['cable']={'size':[64,64],'visible_width':20,'first_last_row_identical':True,'source_period':period,'source_period_match':best[0]}
# Straight sweep: tight content bounds within each phase, then exactly the requested 560x64 band.
im=source('sweep','exec-3e679933-fae8-4125-ad4e-a518ce3a2d81.png');out=Image.new('RGBA',(2304,288))
for row in range(3):
 for col in range(4):
  cell=im.crop((round(col*im.width/4),round(row*im.height/3),round((col+1)*im.width/4),round((row+1)*im.height/3)))
  # Select the principal straight horizontal band; sparse detached halo isn't part of the lane.
  aa=np.array(cell);strength=(aa[:,:,3]>64).sum(1);cy=int(strength.argmax());ys=np.where(strength>strength.max()*.45)[0];y0=max(0,int(ys.min())-2);y1=min(cell.height,int(ys.max())+3)
  core=trim(cell.crop((0,y0,cell.width,y1))).resize((560,64),Image.Resampling.NEAREST)
  out.alpha_composite(core,(col*576+16,row*96+16))
out.save(O/'VFX_anchor_sweep.png')
report['sweep']={'size':[2304,288],'grid':[4,3],'cell':[576,96],'active_rectangle':[16,16,576,80],'rows':['charge_0_0.69','lock_0.69_1.25','strike'],'out_of_cell_pixels':0}
(R/'reports/props.json').write_text(json.dumps(report,indent=2))
print(report)
