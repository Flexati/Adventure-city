from pathlib import Path
from PIL import Image
from scipy import ndimage as nd
import numpy as np, json, subprocess
R=Path(__file__).resolve().parents[1];A=R/'assets';checks=[]
def check(name,ok):
 checks.append({'check':name,'passed':bool(ok)})
 assert ok,name
def arr(n):return np.array(Image.open(A/n).convert('RGBA'))
a=arr('BOSS_anchor_sheet.png');check('G11 dimensions',a.shape==(4096,3072,4))
for r in range(8):
 for c in range(4):
  p=a[r*512:(r+1)*512,c*768:(c+1)*768];lab,_=nd.label(p[:,:,3]>64,np.ones((3,3)));s=np.bincount(lab.ravel());s[0]=0;y,x=np.where(lab==s.argmax());check(f'G11 base {r},{c}',y.max()==493);check(f'G11 clear edges {r},{c}',not np.any(np.concatenate([p[0,:,3],p[-1,:,3],p[:,0,3],p[:,-1,3]])))
for v in ['day','night']:
 a=arr(f'RACE_ashdocks_road_{v}.png');check(f'Road {v} size',a.shape==(1440,720,4));check(f'Road {v} four rows exact',np.array_equal(a[:4],a[-4:]))
a=arr('ARENA_anchor_cable_segment.png');check('Cable size',a.shape==(64,64,4));check('Cable vertical seam',np.array_equal(a[0],a[-1]));check('Cable terminal size',arr('ARENA_anchor_cable_end.png').shape==(64,64,4))
a=arr('VFX_anchor_sweep.png');check('Sweep size',a.shape==(288,2304,4))
for r in range(3):
 for c in range(4):
  p=a[r*96:(r+1)*96,c*576:(c+1)*576,3].copy();p[16:80,16:576]=0;check(f'Sweep rectangle {r},{c}',not p.any())
for state in ['attivo','superato']:
 a=arr(f'RACE_ashdocks_cp_tape_{state}.png');check(f'Tape {state} size',a.shape==(32,64,4));check(f'Tape {state} seam',np.array_equal(a[:,0],a[:,-1]));check(f'Pylon {state} size',arr(f'RACE_ashdocks_cp_pylon_{state}.png').shape==(256,128,4))
for state in ['normale','selezionata','non_disponibile']:check(f'Icon {state} size',arr(f'ICON_h17_{state}.png').shape==(128,128,4))
for p in sorted(A.glob('*')):
 if p.suffix not in ['.ogg','.flac']:continue
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(p)]))['streams'][0];check(p.name+' sample rate',int(info['sample_rate'])==48000)
 x=np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-f','f32le','-']),dtype='<f4');check(p.name+' peak',20*np.log10(abs(x).max())<=-1);check(p.name+' onset',abs(x[0])>1e-4);check(p.name+' duration',len(x)/48000<=(.3 if 'beep' in p.name else 1.5))
(R/'reports/verification.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'human_approval':False,'game_runtime_test':False,'scope':'17 exported files; G6/G7 excluded pending conflicting margin decision'},indent=2));print(len(checks),'checks passed')
