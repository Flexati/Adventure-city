# CHRONOS — pacchetto di produzione per Opus

Repository corretto: **Flexati/Adventure-city**, ramo **work/chronos-adventure-commercial**, commit **71a35ec** (SHA completo in documenti/BASELINE.json). La precedente ricerca su amzajaguar-blip/City-Adventure- riguardava una baseline differente. La PR #7 di quel repository non è la consegna canonica di questo pacchetto.

Aprire nell'ordine:
1. documenti/PROMPT_OPUS.md — incarico pronto da incollare.
2. documenti/INTEGRAZIONE.md — punti reali del codice e formato dei file.
3. documenti/QUALITA_E_LIMITI.md — cosa non può essere accettato automaticamente.
4. documenti/EXPORT_REPORT.json e MANIFEST_SHA256.json — griglie, rettangoli e integrità.
5. documenti_originali/gold/ e documenti_originali/production/v10.2/ — canone, decisioni, contratti e stato autorevole.

## Contenuti
- `asset_nuovi/`: candidati grafici G3–G12, master image_gen conservati, audio A5 in FLAC/OGG. NON integrazione automatica.
- `asset_precedenti_P1/`: G1–G3/A1–A4 recuperati dal repository, con i relativi limiti e registri originali.
- Il codice del gioco non è incluso né modificato. Rimane nel repository corretto; il team dispone anche del proprio ZIP codice V10.2. Nessuno strumento di firma Play è incluso.
- `documenti_originali/`: documentazione recuperata dal ramo corretto, inclusi Excel, CSV, matrice e brief audio originali.
- `documenti/REQUISITI_COMPLETI_460.json`: tutte le richieste originali. P2/P3 non sono dichiarati prodotti da questo pacchetto.
- `strumenti/`: esportazione tecnica dei master e sintesi originale dell'audio A5.

**Stato:** candidati P1 prodotti, da valutare e integrare. Il progetto completo e tutte le 460 famiglie NON sono completati. Nessuna approvazione artistica, ascolto umano, test Android o sblocco commerciale viene attestato. Il test eseguito è `npm test` sulla baseline: 199 passati, 0 falliti; non certifica i nuovi asset.
