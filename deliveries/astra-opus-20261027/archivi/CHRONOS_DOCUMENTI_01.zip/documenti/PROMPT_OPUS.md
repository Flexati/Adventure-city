# Prompt da consegnare a Opus

Lavora su CHRONOS Adventure: Nox & Lulù nel repository Flexati/Adventure-city, ramo work/chronos-adventure-commercial. Il pacchetto allegato è basato sul commit 71a35ec; verifica HEAD attuale, istruzioni AGENTS.md e modifiche locali prima di iniziare. Preserva gli aggiornamenti successivi. Non usare come baseline amzajaguar-blip/City-Adventure- e non importare automaticamente la PR #7 di quel repository.

Leggi LEGGIMI_PRIMA.md, documenti/INTEGRAZIONE.md, QUALITA_E_LIMITI.md, EXPORT_REPORT.json, MANIFEST_SHA256.json e i documenti originali in gold e production/v10.2. Verifica gli hash prima di copiare i file. I master sono conservati; gli export sono candidati, non arte approvata. Non chiudere famiglie per la sola esistenza di un PNG o OGG.

Nox è maschile, Lulù femminile. Mantieni identità, costumi e proporzioni dei protagonisti. Le varianti arma non autorizzano redesign. Confronta gli sheet generati con gli originali; respingi le variazioni indebite. Non inventare nuove conoscenze narrative, poteri o condizioni di sblocco.

Integra soltanto i candidati che superano i controlli. Parti da gare Ash Docks, effetti/icone delle armi e ritratti; poi sheet equipaggiati e The Anchor. Usa mapping, tempi e rettangoli documentati. Le pose nuove sono impaginate con margini ma questo non ripara un dettaglio già tagliato nel master: verifica le celle marcate source_touched_edge.

Per The Anchor preserva invulnerabilità con almeno una cima tesa, Risonanza che taglia una cima, due colpi per cima, lock al 55% della carica di 1,25 s, finestre di esposizione 10/7,5 s, salvataggio e retry. Integra l'audio A5 con gli eventi del modello. Per H17/ARC7 preserva i gate delle ricompense in weapons-v9.mjs.

Esegui npm test, tests/anchor.test.mjs e gli strumenti browser pertinenti alle modifiche (incluso verify_anchor_browser.cjs). Prova risoluzioni mobile verticali/orizzontali, reduced motion, audio mono e loop. Distingui test automatici da ascolto e valutazione umana. Registra i rifiuti con ID famiglia, file, motivo e correzione necessaria. Aggiorna registri solo dopo evidenza reale. P2/P3 restano tracciati nella matrice; per P3 non produrre asset finali prima delle meccaniche.

Alla consegna indica commit, file integrati, test eseguiti, difetti aperti e prossimo blocco concreto. Non dichiarare l'intero gioco completato né COMMERCIAL_RELEASE sbloccata.

La produzione Astra non ha modificato file di gioco. Il codice è stato usato soltanto come riferimento. La consegna esclude il progetto Android e gli strumenti di firma.
