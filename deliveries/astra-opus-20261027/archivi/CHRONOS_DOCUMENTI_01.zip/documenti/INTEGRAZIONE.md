# Contratto operativo di integrazione

## Gare G3–G5
`game/runtime.mjs`: artPath, caricamento immagini, runRace/render gare (circa righe 280–313 nella baseline). Attualmente Veyra usa una cella dell'atlante driving_cars. Non sostituire globalmente tutte le auto.
RACE_veyra_car: 1536×512, 4×2 celle 384×256. Prima riga intatta/danneggiata/molto danneggiata/fumo. Seconda parcheggiata 3/4/frenata/notte1/notte2. Usare le viste dall'alto in gara e la vista 3/4 solo nell'hub.
Strade: 720×1440, cinque corsie; controllare la carreggiata x130–590 e la ripetizione verticale. L'export non certifica la giunzione: vedere i valori misurati in EXPORT_REPORT.
Props: container 128×192; checkpoint 128×256; gate 256×128. Collegare normale/colpito, attivo/superato, aperto/chiuso agli stati, non al solo colore.

## Armi G6–G9
`game/visuals.mjs`: RELOAD_ATLAS, heroFrame, gunRow; `game/runtime.mjs`: artPath e precaricamento delle immagini; `game/weapons-v9.mjs`: parametri, kit e sblocco.
Tiro: 1305×1205, 4×4. Ricarica: 1305×1285, 4×4. La scelta ricarica segue il runtime trovato: RELOAD_DRAW_SCALE=321.25/301.25 e 20 px aggiuntivi per cella. È una deviazione esplicita dal prompt Excel 1305×1205, da conservare nel registro. Non deformare l'immagine per eliminare la deviazione.
Righe lato/schiena/fronte/diagonale-schiena; colonne tiro anticipo/rilascio/rinculo/recupero; ricarica abbassa/estrai/inserisci/pronta. EXPORT_REPORT contiene rettangoli effettivi: usare quelli per evitare arrotondamenti nelle celle frazionarie. Le nuove pose richiedono controllo d'ancoraggio rispetto a walk, non riutilizzare ciecamente gli offset storici.
H17: caricatore 4, ricarica 1,8 s; ARC7: caricatore 8, ricarica 1,5 s. Non cambiare questi tempi per adattarli al disegno.
Icone: sei PNG 128×128; stati normale/selezionata/non_disponibile. VFX: cinque atlanti 512×384, 4×3 celle 128×128, righe proiettile/impatto corpo/impatto muro; verificare ordine temporale e assenza di contaminazione dai frame vicini.

## Ritratti G10
Quattro PNG 512×512; Kairn neutro/allarme, Morrow beffardo/paura. Non inserirli come sostituti dell'intero portraits.png senza mapping. Verificare contro i master dell'autore e i dialoghi esistenti.

## The Anchor G11/G12/A5
`game/runtime.mjs` render del boss circa 658, cime/telegraph circa 725, dispatch eventi circa 618–623; modello e test rimangono autorità dei tempi. Sprite 4×8: idle, carica cima, rilascio, recupero, peso, danno, sconfitta, esposto. Dimensione export 3072×4096, celle 768×512; questa scelta di impaginazione è tecnica e non stabilisce la scala mondo.
Bitte 128×192 nei tre stati; cavo 64×256; sweep 1024×384, 4×3 celle 256×128. Il cavo generato ha terminali: non ripeterlo integralmente senza distinguere segmento centrale e terminali. Non alterare le hitbox per seguire i VFX.
Audio: anchorMoored→anchor_moor; anchorExposed→anchor_exposed; anchorRelink→anchor_relink; anchorSweepWarn→anchor_line_tension; anchorSweep→anchor_sweep. Collegare taglio cima e attacco peso agli eventi reali del modello per anchor_line_cut/anchor_weight. anchor_fight_loop è un loop di 80 s; avvio/uscita devono seguire combattimento, vittoria, pausa e retry.

## Importazione prudente
Copiare solo gli asset accettati in assets/production/v10.2/handoff/; creare runtime derivati nei percorsi concordati. Conservare i master e i registri. Il codice è solo riferimento: non integrare e non modificare file di gioco durante la produzione Astra. Integrazione e verifica spettano a Opus/team nel checkout completo.
