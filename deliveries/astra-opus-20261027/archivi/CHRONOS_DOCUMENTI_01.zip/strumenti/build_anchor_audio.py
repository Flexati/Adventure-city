"""Original, deterministic modal synthesis. No recordings or sampled music used.
Requires numpy, scipy and ffmpeg. Run from the repository root.
"""
import json, subprocess, tempfile, hashlib
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt
SR=48000
OUT=Path('assets/production/v10.2/handoff/audio-candidates')
RNG=np.random.default_rng(271026)
def noise(n, low=100, high=7000):
    return sosfilt(butter(2,[low,high],fs=SR,btype='bandpass',output='sos'),RNG.normal(0,1,n))
def metal(d, f=130, decay=5):
    t=np.arange(round(d*SR))/SR
    x=sum(np.sin(2*np.pi*f*r*t)*np.exp(-decay*(1+i*.22)*t)/(i+1) for i,r in enumerate([1,1.47,2.13,3.71,5.19]))
    return x+noise(len(t))*np.exp(-40*t)*.35
def put(dst, x, when, gain=1):
    start=round(when*SR); n=min(len(x),len(dst)-start)
    if n>0:dst[start:start+n]+=x[:n]*gain
def effect(name):
    d={'anchor_moor':1.45,'anchor_line_tension':1.25,'anchor_sweep':1.2,'anchor_line_cut':1.,'anchor_relink':1.3,'anchor_exposed':1.45,'anchor_weight':1.4}[name]
    t=np.arange(round(d*SR))/SR;x=np.zeros(len(t))
    if name=='anchor_moor':
        for i in range(8):put(x,metal(.4,170+i*13,12),i*.105,.22+i*.03)
        put(x,metal(.7,58,6),.72,.7)
    elif name=='anchor_line_tension':
        lock=.55*d
        freq=np.where(t<lock,150+330*t/lock,480.)
        phase=2*np.pi*np.cumsum(freq)/SR
        env=.2+.65*np.minimum(t/lock,1)
        x=env*(np.sin(phase)*.35+np.sin(phase*2.13)*.16)+noise(len(t),900,5000)*env*.12
        put(x,metal(.24,760,24),lock,.5)
        x[t>=lock]+=np.sin(phase[t>=lock]*3)*.18
    elif name=='anchor_sweep':
        x=noise(len(t),180,6500)*np.exp(-((t-.22)/.15)**2)*1.2
        put(x,metal(.9,78,8),.18,.65)
        x+=noise(len(t),80,900)*np.exp(-5*t)*.18
    elif name=='anchor_line_cut':
        x=metal(d,310,13)*.6+noise(len(t),1200,9500)*np.exp(-35*t)*.9
        x+=np.sin(2*np.pi*(640*t-230*t*t))*np.exp(-12*t)*.25
    elif name=='anchor_relink':
        for i in range(4):put(x,metal(.4,250-i*35,18),i*.16,.35)
        put(x,metal(.7,94,7),.52,.85)
    elif name=='anchor_exposed':
        x=metal(d,92,5)*.45
        env=(1-np.exp(-12*t))*np.exp(-1.8*t)
        x+=sum(np.sin(2*np.pi*f*t)*env*.12 for f in [146.83,220,293.66])
        x+=np.sin(2*np.pi*(700*t-180*t*t))*np.exp(-5*t)*.13
    else:
        x=metal(d,49,6)*.9+noise(len(t),60,1500)*np.exp(-7*t)*.6
        for i in range(4):put(x,metal(.35,220+i*53,15),.16+i*.1,.13)
    x[:48]*=np.linspace(0,1,48);x[-960:]*=np.linspace(1,0,960)
    return x

def score():
    # 32 bars of 4/4, 96 BPM = 80 seconds; wrap every tail, no fade at seam.
    duration=80; n=duration*SR;x=np.zeros(n);beat=.625
    def event(y,at,gain):
        indices=(round(at*SR)+np.arange(len(y)))%n
        np.add.at(x,indices,y*gain)
    for bar in range(32):
        root=[73.416,73.416,65.406,55.][(bar//4)%4]
        for b in [0,2.5]:event(metal(.7,52,8), (bar*4+b)*beat,.18)
        for b in [.75,1.75,3.25]:event(metal(.3,330+(bar%3)*47,22),(bar*4+b)*beat,.035)
        t=np.arange(SR*2)/SR
        env=(1-np.exp(-70*t))*np.exp(-2.5*t)
        bass=(np.sin(2*np.pi*root*t)+.22*np.sin(2*np.pi*root*3*t))*env
        event(bass,bar*4*beat,.18)
        # Two short repeated knocks followed by a warmer answer, every four bars.
        if bar%4==0:
            for b in [0,.5]:event(metal(.8,146.83,7),(bar*4+b)*beat,.11)
            event(metal(2.,220,2.8),(bar*4+2)*beat,.075)
    t=np.arange(n)/SR
    # Frequencies chosen on the 1/80-Hz lattice make the quiet bed periodic.
    x+=.012*np.sin(2*np.pi*55*t)+.009*np.sin(2*np.pi*82.5*t)*(1+.3*np.sin(2*np.pi*t/20))
    return x

def encode(name,x):
    x=x/max(np.max(np.abs(x)),1e-9)*10**(-3.5/20)
    with tempfile.TemporaryDirectory() as tmp:
        wav=Path(tmp)/'source.wav';wavfile.write(wav,SR,x.astype(np.float32))
        for ext,codec in [('flac',['-c:a','flac','-sample_fmt','s32']),('ogg',['-c:a','libvorbis','-q:a','6'])]:
            subprocess.run(['ffmpeg','-v','error','-y','-i',str(wav),*codec,str(OUT/f'{name}.{ext}')],check=True)
    checks={}
    for ext in ['flac','ogg']:
        f=OUT/f'{name}.{ext}'
        raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(f),'-f','f32le','-ac','1','-ar',str(SR),'-'])
        a=np.frombuffer(raw,dtype='<f4');peak=float(20*np.log10(max(np.max(np.abs(a)),1e-12)))
        assert peak<=-1,(name,ext,peak)
        assert abs(len(a)/SR-len(x)/SR)<.03
        checks[ext]={'peak_dbfs':peak,'seconds':len(a)/SR,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'sample_rate':SR}
        if 'loop' in name:checks[ext]['boundary_sample_step']=float(abs(a[-1]-a[0]))
    return checks
if __name__=='__main__':
    OUT.mkdir(parents=True,exist_ok=True)
    names=['anchor_moor','anchor_line_tension','anchor_sweep','anchor_line_cut','anchor_relink','anchor_exposed','anchor_weight']
    results={name:encode(name,effect(name)) for name in names}
    results['anchor_fight_loop']=encode('anchor_fight_loop',score())
    report={'status':'TECHNICAL_CHECKS_ONLY_AWAITING_LISTENING_AND_RUNTIME','tool':'Python numpy/scipy modal synthesis; ffmpeg FLAC and libvorbis','seed':271026,'recordings_or_external_music_used':False,'human_listening':False,'runtime_test':False,'tension_lock_seconds':1.25*.55,'music':{'bpm':96,'bars':32,'meter':'4/4','seconds':80},'files':results}
    (OUT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v['ogg'] for k,v in results.items()},indent=2))
