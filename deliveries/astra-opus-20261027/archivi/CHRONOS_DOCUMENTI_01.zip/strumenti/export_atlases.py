"""Technical export of image_gen masters: cell extraction and proportional packing.
No new artwork is drawn. Masters are preserved. Outputs require artistic/runtime review.
"""
from pathlib import Path
import json,shutil
from PIL import Image
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'asset_nuovi'; GEN=Path('/workspace/generated_images')
MAP=ROOT/'strumenti/master_map.json'
report=[]
def master(key):
 p=OUT/'masters'/f'{key}.png'
 if not p.exists():
  p=GEN/json.loads(MAP.read_text())[key]
  shutil.copy2(p,OUT/'masters'/f'{key}.png')
 return Image.open(p).convert('RGBA')
def split(im,cols,rows):
 out=[]
 for r in range(rows):
  for c in range(cols):
   box=(round(c*im.width/cols),round(r*im.height/rows),round((c+1)*im.width/cols),round((r+1)*im.height/rows))
   cell=im.crop(box)
   # Ignore near-transparent generator dust when measuring a pose, retain visible alpha.
   alpha=cell.getchannel('A');box=alpha.point(lambda x:255 if x>6 else 0).getbbox()
   if box is None: raise ValueError(f'Empty cell {r},{c}')
   out.append((cell.crop(box),box,cell.size))
 return out
def atlas(name,cells,cols,rows,size,source,baseline=False):
 cw,ch=size[0]/cols,size[1]/rows
 scale=min(min((cw-32)/im.width,(ch-32)/im.height) for im,_,_ in cells)
 canvas=Image.new('RGBA',size);checks=[]
 for i,(im,box,oldsize) in enumerate(cells):
  r,c=divmod(i,cols);dims=(max(1,round(im.width*scale)),max(1,round(im.height*scale)))
  im=im.resize(dims,Image.Resampling.NEAREST)
  x=round(c*cw+(cw-im.width)/2);y=round(r*ch+(ch-im.height-16 if baseline else (ch-im.height)/2))
  canvas.alpha_composite(im,(x,y))
  checks.append({'row':r,'col':c,'rect':[x,y,im.width,im.height],'source_cell_bbox':box,'source_touched_edge':box[0]==0 or box[1]==0 or box[2]==oldsize[0] or box[3]==oldsize[1]})
 canvas.save(OUT/name)
 report.append({'file':name,'source':source,'dimensions':size,'grid':[cols,rows],'scale':scale,'cells':checks,'status':'CANDIDATE_NOT_RUNTIME_APPROVED'})
def singles(key,cols,rows,names,sizes):
 cells=split(master(key),cols,rows)
 for i,(name,size) in enumerate(zip(names,sizes)):atlas(name,[cells[i]],1,1,size,key)
if __name__=='__main__':
 mapping=json.loads(MAP.read_text())
 if 'G3' in mapping:atlas('RACE_veyra_car.png',split(master('G3'),4,2),4,2,(1536,512),'G3')
 for v in ['day','night']:
  key='G4_'+v
  if key in mapping:
   im=master(key).convert('RGB').resize((720,1440),Image.Resampling.NEAREST);name=f'RACE_ashdocks_road_{v}.png';im.save(OUT/name)
   a=np.array(im).astype(float)
   report.append({'file':name,'source':key,'dimensions':[720,1440],'seam_mean_absolute_rgb_difference':float(np.abs(a[0]-a[-1]).mean()),'status':'CANDIDATE_SEAM_AND_LANE_WIDTH_REQUIRE_REVIEW'})
 if 'G5' in mapping:
  singles('G5',3,2,['RACE_ashdocks_container_normale.png','RACE_ashdocks_container_colpito.png','RACE_ashdocks_cp_attivo.png','RACE_ashdocks_cp_superato.png','RACE_ashslalom_gate_aperto.png','RACE_ashslalom_gate_chiuso.png'],[(128,192)]*2+[(128,256)]*2+[(256,128)]*2)
 for g,hero,weapon in [('G6','nox','h17'),('G7','lulu','arc7')]:
  for state,h in [('gun',1205),('reload',1285)]:
   key=g+'_'+state
   if key in mapping:atlas(f'{hero}_{weapon}_{state}.png',split(master(key),4,4),4,4,(1305,h),key,True)
 if 'G8' in mapping:singles('G8',3,2,[f'ICON_{w}_{s}.png' for w in ['h17','arc7'] for s in ['normale','selezionata','non_disponibile']],[(128,128)]*6)
 if 'G9' in mapping:
  cells=split(master('G9'),4,15)
  for i,w in enumerate(['c9','vx9','r12','h17','arc7']):atlas(f'VFX_{w}_impact.png',cells[i*12:(i+1)*12],4,3,(512,384),'G9')
 if 'G10' in mapping:singles('G10',2,2,['PORTRAIT_kairn_neutro.png','PORTRAIT_kairn_allarme.png','PORTRAIT_morrow_beffardo.png','PORTRAIT_morrow_paura.png'],[(512,512)]*4)
 if 'G11' in mapping:atlas('BOSS_anchor_sheet.png',split(master('G11'),4,8),4,8,(3072,4096),'G11',True)
 if 'G12' in mapping:
  cells=split(master('G12'),4,4)
  for i,s in enumerate(['tesa','tagliata','riormeggio']):atlas(f'ARENA_anchor_bollard_{s}.png',[cells[i]],1,1,(128,192),'G12')
  atlas('ARENA_anchor_cable.png',[cells[3]],1,1,(64,256),'G12')
  atlas('VFX_anchor_sweep.png',cells[4:],4,3,(1024,384),'G12')
 (ROOT/'documenti/EXPORT_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
 print('Exported',len(report),'PNGs')
