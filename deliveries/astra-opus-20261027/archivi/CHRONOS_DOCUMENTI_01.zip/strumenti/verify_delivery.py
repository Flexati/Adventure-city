"""Verify integrity and technical export geometry, without claiming artistic approval."""
import hashlib,json
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[1]
errors=[]
for item in json.loads((root/'MANIFEST_SHA256.json').read_text()):
 p=root/item['path']
 if not p.is_file():errors.append('missing '+item['path']);continue
 if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:errors.append('hash '+item['path'])
for item in json.loads((root/'documenti/EXPORT_REPORT.json').read_text()):
 im=Image.open(root/'asset_nuovi'/item['file'])
 if list(im.size)!=item['dimensions']:errors.append('dimensions '+item['file'])
 if 'cells' in item:
  cols,rows=item['grid'];cw,ch=im.width/cols,im.height/rows
  for cell in item['cells']:
   x,y,w,h=cell['rect'];c,r=cell['col'],cell['row']
   if min(x-c*cw,y-r*ch,(c+1)*cw-x-w,(r+1)*ch-y-h)<12:
    errors.append(f"margin {item['file']} {r},{c}")
print(json.dumps({'integrity_geometry_errors':errors,'artistic_acceptance':'NOT_ASSERTED'},indent=2))
raise SystemExit(bool(errors))
